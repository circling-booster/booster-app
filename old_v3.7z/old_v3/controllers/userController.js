const userService = require('../services/userService');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');
const { validatePassword, validatePhoneNumber } = require('../utils/validationUtils');

async function getProfile(req, res) {
    try {
        const userId = req.user.userId;
        const userInfo = await userService.getUserInfo(userId);
        
        successResponse(res, userInfo, '사용자 정보 조회 성공');
    } catch (err) {
        if (err.message.includes('찾을 수 없습니다')) {
            return errorResponse(res, err.message, 404, 'USER_NOT_FOUND');
        }
        errorResponse(res, err.message, 500);
    }
}

async function updateProfile(req, res) {
    try {
        const userId = req.user.userId;
        const { firstName, lastName, phoneNumber, email } = req.body;
        
        if (phoneNumber && !validatePhoneNumber(phoneNumber)) {
            return errorResponse(res, '유효한 휴대폰 번호를 입력하세요', 400, 'INVALID_PHONE');
        }
        
        const updatedUser = await userService.updateUserProfile(userId, {
            firstName,
            lastName,
            phoneNumber,
            email
        });
        
        successResponse(res, updatedUser, '프로필 수정 성공');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function changePassword(req, res) {
    try {
        const userId = req.user.userId;
        const { oldPassword, newPassword, confirmPassword } = req.body;
        
        if (!oldPassword || !newPassword) {
            return errorResponse(res, '현재 비밀번호와 새 비밀번호는 필수입니다', 400);
        }
        
        if (newPassword !== confirmPassword) {
            return errorResponse(res, '새 비밀번호가 일치하지 않습니다', 400);
        }
        
        if (!validatePassword(newPassword)) {
            return errorResponse(res, '비밀번호는 최소 8자이며 대문자, 소문자, 숫자, 특수문자를 포함해야 합니다', 400);
        }
        
        await userService.changePassword(userId, oldPassword, newPassword);
        
        successResponse(res, null, '비밀번호 변경 성공');
    } catch (err) {
        if (err.message.includes('일치하지 않습니다')) {
            return errorResponse(res, err.message, 401, 'INVALID_PASSWORD');
        }
        errorResponse(res, err.message, 500);
    }
}

module.exports = {
    getProfile,
    updateProfile,
    changePassword
};
