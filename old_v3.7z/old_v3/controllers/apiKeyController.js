const apiKeyService = require('../services/apiKeyService');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');

async function createApiKey(req, res) {
    try {
        const userId = req.user.userId;
        const { keyName } = req.body;
        
        if (!keyName) {
            return errorResponse(res, 'Key name은 필수입니다', 400);
        }
        
        const result = await apiKeyService.generateNewApiKey(userId, keyName);
        
        successResponse(res, result, 'API Key가 생성되었습니다', 201);
    } catch (err) {
        if (err.message.includes('구독')) {
            return errorResponse(res, err.message, 403, 'NO_ACTIVE_SUBSCRIPTION');
        }
        errorResponse(res, err.message, 500);
    }
}

async function getApiKeys(req, res) {
    try {
        const userId = req.user.userId;
        const keys = await apiKeyService.getUserApiKeys(userId);
        
        successResponse(res, keys, 'API Key 목록 조회 성공');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function revokeApiKey(req, res) {
    try {
        const userId = req.user.userId;
        const { keyId } = req.params;
        
        await apiKeyService.revokeApiKey(userId, keyId);
        
        successResponse(res, null, 'API Key가 비활성화되었습니다');
    } catch (err) {
        if (err.message.includes('찾을 수 없습니다')) {
            return errorResponse(res, err.message, 404, 'API_KEY_NOT_FOUND');
        }
        errorResponse(res, err.message, 500);
    }
}

module.exports = {
    createApiKey,
    getApiKeys,
    revokeApiKey
};
