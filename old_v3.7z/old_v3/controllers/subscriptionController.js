const subscriptionService = require('../services/subscriptionService');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');

async function requestSubscription(req, res) {
    try {
        const userId = req.user.userId;
        const { tierId } = req.body;
        
        if (!tierId) {
            return errorResponse(res, 'Tier ID는 필수입니다', 400);
        }
        
        const subscriptionId = await subscriptionService.requestSubscription(userId, tierId);
        
        successResponse(res, { subscriptionId }, '구독 신청이 완료되었습니다', 201);
    } catch (err) {
        if (err.message.includes('이미 활성화')) {
            return errorResponse(res, err.message, 409, 'SUBSCRIPTION_ALREADY_EXISTS');
        }
        errorResponse(res, err.message, 500);
    }
}

async function getMySubscription(req, res) {
    try {
        const userId = req.user.userId;
        const subscription = await subscriptionService.getUserSubscription(userId);
        
        if (!subscription) {
            return successResponse(res, null, '구독 정보가 없습니다');
        }
        
        successResponse(res, subscription, '구독 정보 조회 성공');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function getSubscriptionTiers(req, res) {
    try {
        const tiers = await subscriptionService.getSubscriptionTiers();
        successResponse(res, tiers, '구독 Tier 조회 성공');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

module.exports = {
    requestSubscription,
    getMySubscription,
    getSubscriptionTiers
};
