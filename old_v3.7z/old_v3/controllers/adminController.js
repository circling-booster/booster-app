const adminService = require('../services/adminService');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');

async function getAllUsers(req, res) {
    try {
        const { page = 1, limit = 20 } = req.query;
        const result = await adminService.getAllUsers(parseInt(page), parseInt(limit));
        
        successResponse(res, result, '사용자 목록 조회 성공');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function getPendingSubscriptions(req, res) {
    try {
        const { page = 1, limit = 20 } = req.query;
        const result = await adminService.getPendingSubscriptions(parseInt(page), parseInt(limit));
        
        successResponse(res, result, '대기중인 구독 목록 조회 성공');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function approveSubscription(req, res) {
    try {
        const { subscriptionId } = req.params;
        const adminId = req.user.userId;
        
        await adminService.approveSubscription(subscriptionId, adminId);
        
        successResponse(res, null, '구독이 승인되었습니다');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function rejectSubscription(req, res) {
    try {
        const { subscriptionId } = req.params;
        const { reason } = req.body;
        
        await adminService.rejectSubscription(subscriptionId, reason);
        
        successResponse(res, null, '구독이 거절되었습니다');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function blockUser(req, res) {
    try {
        const { userId } = req.params;
        const { reason } = req.body;
        
        await adminService.blockUser(userId, reason);
        
        successResponse(res, null, '사용자가 차단되었습니다');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function unblockUser(req, res) {
    try {
        const { userId } = req.params;
        
        await adminService.unblockUser(userId);
        
        successResponse(res, null, '사용자 차단이 해제되었습니다');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

async function getSystemStats(req, res) {
    try {
        const stats = await adminService.getSystemStats();
        
        successResponse(res, stats, '시스템 통계 조회 성공');
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

module.exports = {
    getAllUsers,
    getPendingSubscriptions,
    approveSubscription,
    rejectSubscription,
    blockUser,
    unblockUser,
    getSystemStats
};
