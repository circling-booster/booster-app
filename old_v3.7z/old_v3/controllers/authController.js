const authService = require('../services/authService');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');
const { validateSignupInput } = require('../utils/validationUtils');

async function signup(req, res) {
    try {
        const { firstName, lastName, email, phoneNumber, password, confirmPassword } = req.body;
        
        // 입력 검증
        const validation = validateSignupInput({
            firstName,
            lastName,
            email,
            phoneNumber,
            password
        });
        
        if (!validation.isValid) {
            return errorResponse(res, '입력값 검증 실패', 400, 'VALIDATION_ERROR', validation.errors);
        }
        
        if (password !== confirmPassword) {
            return errorResponse(res, '비밀번호가 일치하지 않습니다', 400, 'PASSWORD_MISMATCH');
        }
        
        const userId = await authService.registerUser({
            firstName,
            lastName,
            email,
            phoneNumber,
            password
        });
        
        successResponse(res, { userId }, '회원가입이 완료되었습니다', 201);
    } catch (err) {
        if (err.message.includes('이미 등록')) {
            return errorResponse(res, err.message, 409, 'EMAIL_ALREADY_EXISTS');
        }
        errorResponse(res, err.message, 500);
    }
}

async function login(req, res) {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return errorResponse(res, '이메일과 비밀번호는 필수입니다', 400, 'MISSING_CREDENTIALS');
        }
        
        const result = await authService.loginUser(email, password);
        
        successResponse(res, result, '로그인 성공');
    } catch (err) {
        if (err.message.includes('가입되지 않은') || err.message.includes('비밀번호')) {
            return errorResponse(res, err.message, 401, 'INVALID_CREDENTIALS');
        }
        if (err.message.includes('차단') || err.message.includes('비활성화')) {
            return errorResponse(res, err.message, 403, 'USER_BLOCKED');
        }
        errorResponse(res, err.message, 500);
    }
}

async function refreshToken(req, res) {
    try {
        const { refreshToken } = req.body;
        
        if (!refreshToken) {
            return errorResponse(res, '리프레시 토큰이 필요합니다', 400, 'MISSING_REFRESH_TOKEN');
        }
        
        const newAccessToken = await authService.refreshAccessToken(refreshToken);
        
        successResponse(res, { accessToken: newAccessToken }, '토큰 갱신 성공');
    } catch (err) {
        errorResponse(res, err.message, 401, 'INVALID_REFRESH_TOKEN');
    }
}

module.exports = {
    signup,
    login,
    refreshToken
};
