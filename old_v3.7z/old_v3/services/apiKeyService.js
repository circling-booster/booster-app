const { executeQuery, executeNonQuery } = require('../config/database');
const { generateApiKey, generateApiSecret, encryptApiSecret } = require('../utils/cryptoUtils');
const { isSubscriptionActive } = require('./subscriptionService');

async function generateNewApiKey(userId, keyName) {
    try {
        // 구독 활성화 확인
        const isActive = await isSubscriptionActive(userId);
        
        if (!isActive) {
            throw new Error('활성화된 구독이 없습니다');
        }
        
        const apiKey = generateApiKey();
        const apiSecret = generateApiSecret();
        const secretHash = encryptApiSecret(apiSecret);
        const keyId = require('crypto').randomUUID();
        
        // API Key 저장
        await executeNonQuery(
            `INSERT INTO [ApiKeys] 
             (id, user_id, key_name, api_key, api_secret_hash, is_active)
             VALUES (@id, @userId, @keyName, @apiKey, @secretHash, 1)`,
            {
                id: keyId,
                userId,
                keyName,
                apiKey,
                secretHash
            }
        );
        
        return {
            keyId,
            apiKey,
            apiSecret,
            // Secret은 한 번만 노출됨
            warning: 'API Secret은 한 번만 표시됩니다. 안전한 곳에 저장하세요'
        };
    } catch (err) {
        throw err;
    }
}

async function getUserApiKeys(userId) {
    try {
        const keys = await executeQuery(
            `SELECT id, key_name, LEFT(api_key, 10) as key_preview, is_active, last_used, created_at 
             FROM [ApiKeys]
             WHERE user_id = @userId
             ORDER BY created_at DESC`,
            { userId }
        );
        
        return keys;
    } catch (err) {
        throw err;
    }
}

async function revokeApiKey(userId, keyId) {
    try {
        // 사용자 소유 확인
        const keys = await executeQuery(
            'SELECT id FROM [ApiKeys] WHERE id = @keyId AND user_id = @userId',
            { keyId, userId }
        );
        
        if (keys.length === 0) {
            throw new Error('API Key를 찾을 수 없습니다');
        }
        
        // 비활성화
        await executeNonQuery(
            'UPDATE [ApiKeys] SET is_active = 0 WHERE id = @keyId',
            { keyId }
        );
    } catch (err) {
        throw err;
    }
}

async function validateApiKey(apiKey, apiSecret) {
    try {
        const secretHash = encryptApiSecret(apiSecret);
        
        const keys = await executeQuery(
            `SELECT id, user_id, is_active FROM [ApiKeys] 
             WHERE api_key = @apiKey AND api_secret_hash = @secretHash AND is_active = 1`,
            { apiKey, secretHash }
        );
        
        if (keys.length === 0) {
            throw new Error('유효하지 않은 API Key 또는 Secret입니다');
        }
        
        // 마지막 사용 시간 업데이트
        await executeNonQuery(
            'UPDATE [ApiKeys] SET last_used = GETDATE() WHERE id = @id',
            { id: keys.id }
        );
        
        return keys;
    } catch (err) {
        throw err;
    }
}

module.exports = {
    generateNewApiKey,
    getUserApiKeys,
    revokeApiKey,
    validateApiKey
};
