const { executeQuery, executeNonQuery } = require('../config/database');
const { hashPassword, verifyPassword, generateApiKey, generateApiSecret, encryptApiSecret } = require('../utils/cryptoUtils');
const { generateAccessToken, generateRefreshToken } = require('../utils/tokenUtils');
const { validateEmail } = require('../utils/validationUtils');

async function registerUser(userData) {
    try {
        // 기존 사용자 확인
        const existingUser = await executeQuery(
            'SELECT id FROM [Users] WHERE email = @email',
            { email: userData.email }
        );
        
        if (existingUser.length > 0) {
            throw new Error('이미 등록된 이메일입니다');
        }
        
        // 비밀번호 해싱
        const passwordHash = await hashPassword(userData.password);
        
        // 사용자 생성
        const userId = require('crypto').randomUUID();
        
        await executeNonQuery(
            `INSERT INTO [Users] 
             (id, first_name, last_name, email, phone_number, password_hash)
             VALUES (@id, @firstName, @lastName, @email, @phoneNumber, @passwordHash)`,
            {
                id: userId,
                firstName: userData.firstName,
                lastName: userData.lastName,
                email: userData.email,
                phoneNumber: userData.phoneNumber,
                passwordHash
            }
        );
        
        return userId;
    } catch (err) {
        throw err;
    }
}

async function loginUser(email, password) {
    try {
        // 사용자 조회
        const users = await executeQuery(
            `SELECT id, password_hash, is_active, is_blocked FROM [Users] 
             WHERE email = @email`,
            { email }
        );
        
        if (users.length === 0) {
            throw new Error('가입되지 않은 이메일입니다');
        }
        
        const user = users;
        
        // 차단 상태 확인
        if (user.is_blocked) {
            throw new Error('차단된 계정입니다');
        }
        
        if (!user.is_active) {
            throw new Error('비활성화된 계정입니다');
        }
        
        // 비밀번호 검증
        const isPasswordValid = await verifyPassword(password, user.password_hash);
        
        if (!isPasswordValid) {
            throw new Error('비밀번호가 일치하지 않습니다');
        }
        
        // 마지막 로그인 업데이트
        await executeNonQuery(
            'UPDATE [Users] SET last_login = GETDATE() WHERE id = @id',
            { id: user.id }
        );
        
        // 토큰 생성
        const accessToken = generateAccessToken(user.id);
        const refreshToken = generateRefreshToken(user.id);
        
        return {
            userId: user.id,
            accessToken,
            refreshToken
        };
    } catch (err) {
        throw err;
    }
}

async function refreshAccessToken(refreshToken) {
    try {
        const { verifyToken } = require('../utils/tokenUtils');
        const decoded = verifyToken(refreshToken, true);
        
        if (!decoded) {
            throw new Error('유효하지 않은 리프레시 토큰입니다');
        }
        
        const newAccessToken = generateAccessToken(decoded.userId);
        return newAccessToken;
    } catch (err) {
        throw err;
    }
}

module.exports = {
    registerUser,
    loginUser,
    refreshAccessToken
};
