const express = require('express');
const router = express.Router();
const subscriptionController = require('../controllers/subscriptionController');
const { authMiddleware } = require('../middleware/authMiddleware');

router.post('/subscriptions/request', authMiddleware, subscriptionController.requestSubscription);
router.get('/subscriptions/my-subscription', authMiddleware, subscriptionController.getMySubscription);
router.get('/subscriptions/tiers', authMiddleware, subscriptionController.getSubscriptionTiers);

module.exports = router;
