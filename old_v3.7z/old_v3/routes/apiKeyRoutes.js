const express = require('express');
const router = express.Router();
const apiKeyController = require('../controllers/apiKeyController');
const { authMiddleware } = require('../middleware/authMiddleware');

router.post('/api-keys', authMiddleware, apiKeyController.createApiKey);
router.get('/api-keys', authMiddleware, apiKeyController.getApiKeys);
router.delete('/api-keys/:keyId', authMiddleware, apiKeyController.revokeApiKey);

module.exports = router;
