module.exports = {
    // 구독 상태
    SUBSCRIPTION_STATUS: {
        PENDING: 'pending',
        ACTIVE: 'active',
        EXPIRED: 'expired',
        CANCELLED: 'cancelled'
    },
    
    // API Key 상태
    API_KEY_STATUS: {
        ACTIVE: 'active',
        INACTIVE: 'inactive',
        EXPIRED: 'expired'
    },
    
    // Rate Limit 종류
    RATE_LIMIT_TYPE: {
        HOURLY: 'hourly',
        MONTHLY: 'monthly',
        IP_BASED: 'ip_based'
    },
    
    // 구독 Tier
    SUBSCRIPTION_TIER: {
        BASIC: 'Basic',
        PREMIUM: 'Premium',
        ENTERPRISE: 'Enterprise'
    },
    
    // Tier별 API 호출 제한
    API_CALL_LIMITS: {
        'Basic': 1000,
        'Premium': 5000,
        'Enterprise': 999999
    },
    
    // Webhook 이벤트 종류
    WEBHOOK_EVENTS: {
        SUBSCRIPTION_ACTIVATED: 'subscription_activated',
        SUBSCRIPTION_EXPIRED: 'subscription_expired',
        SUBSCRIPTION_CANCELLED: 'subscription_cancelled',
        API_LIMIT_REACHED: 'api_limit_reached',
        API_LIMIT_WARNING: 'api_limit_warning',
        USER_BLOCKED: 'user_blocked'
    },
    
    // 에러 코드
    ERROR_CODES: {
        INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
        USER_NOT_FOUND: 'USER_NOT_FOUND',
        USER_BLOCKED: 'USER_BLOCKED',
        SUBSCRIPTION_INACTIVE: 'SUBSCRIPTION_INACTIVE',
        API_LIMIT_EXCEEDED: 'API_LIMIT_EXCEEDED',
        INVALID_API_KEY: 'INVALID_API_KEY',
        INVALID_TOKEN: 'INVALID_TOKEN',
        UNAUTHORIZED: 'UNAUTHORIZED',
        FORBIDDEN: 'FORBIDDEN',
        NOT_FOUND: 'NOT_FOUND',
        INTERNAL_ERROR: 'INTERNAL_ERROR'
    }
};
