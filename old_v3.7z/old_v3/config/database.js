const mssql = require('mssql');

const sqlConfig = {
    server: process.env.DB_SERVER,
    database: process.env.DB_DATABASE,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    encrypt: process.env.DB_ENCRYPTION === 'true',
    trustServerCertificate: process.env.DB_TRUST_CERTIFICATE === 'true',
    connectionTimeout: 30000,
    requestTimeout: 30000,
    authentication: {
        type: 'default'
    }
};

let pool = null;

async function initializePool() {
    try {
        pool = new mssql.ConnectionPool(sqlConfig);
        await pool.connect();
        console.log('✅ 데이터베이스 연결 성공');
        
        // 연결 풀 에러 처리
        pool.on('error', err => {
            console.error('데이터베이스 풀 에러:', err);
        });
        
        return pool;
    } catch (err) {
        console.error('❌ 데이터베이스 연결 실패:', err);
        throw err;
    }
}

async function getPool() {
    if (!pool) {
        await initializePool();
    }
    return pool;
}

async function executeQuery(query, params = {}) {
    try {
        const pool = await getPool();
        const request = pool.request();
        
        // 파라미터 바인딩
        for (const [key, value] of Object.entries(params)) {
            request.input(key, value);
        }
        
        const result = await request.query(query);
        return result.recordset;
    } catch (err) {
        console.error('쿼리 실행 에러:', err);
        throw err;
    }
}

async function executeNonQuery(query, params = {}) {
    try {
        const pool = await getPool();
        const request = pool.request();
        
        for (const [key, value] of Object.entries(params)) {
            request.input(key, value);
        }
        
        await request.query(query);
    } catch (err) {
        console.error('Non-Query 실행 에러:', err);
        throw err;
    }
}

async function closePool() {
    if (pool) {
        await pool.close();
        console.log('데이터베이스 연결 종료');
    }
}

module.exports = {
    initializePool,
    getPool,
    executeQuery,
    executeNonQuery,
    closePool
};
