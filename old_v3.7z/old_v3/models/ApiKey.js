class ApiKey {
    static FIELDS = {
        id: 'id',
        userId: 'user_id',
        keyName: 'key_name',
        apiKey: 'api_key',
        apiSecretHash: 'api_secret_hash',
        isActive: 'is_active',
        lastUsed: 'last_used',
        ipWhitelist: 'ip_whitelist',
        createdAt: 'created_at',
        expiresAt: 'expires_at'
    };

    static TABLE = 'ApiKeys';
}

module.exports = ApiKey;
