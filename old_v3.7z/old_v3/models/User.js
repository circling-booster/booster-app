// User 모델 정의 (DB 쿼리 헬퍼)
class User {
    static FIELDS = {
        id: 'id',
        firstName: 'first_name',
        lastName: 'last_name',
        email: 'email',
        phoneNumber: 'phone_number',
        passwordHash: 'password_hash',
        isAdmin: 'is_admin',
        isActive: 'is_active',
        isBlocked: 'is_blocked',
        blockedReason: 'blocked_reason',
        createdAt: 'created_at',
        updatedAt: 'updated_at',
        lastLogin: 'last_login'
    };

    static TABLE = 'Users';

    static getSelectQuery(where = '') {
        const query = `SELECT * FROM [${this.TABLE}]`;
        return where ? `${query} WHERE ${where}` : query;
    }

    static getInsertQuery(data) {
        const fields = Object.keys(data);
        const values = fields.map(f => `@${f}`).join(', ');
        const fieldNames = fields.map(f => this.FIELDS[f] || f).join(', ');
        
        return `INSERT INTO [${this.TABLE}] (${fieldNames}) VALUES (${values})`;
    }

    static getUpdateQuery(data, whereId) {
        const updates = Object.keys(data)
            .map(key => `${this.FIELDS[key] || key} = @${key}`)
            .join(', ');
        
        return `UPDATE [${this.TABLE}] SET ${updates} WHERE id = @id`;
    }
}

module.exports = User;
