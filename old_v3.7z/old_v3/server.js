// server.js의 최종 버전

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const { initializePool } = require('./config/database');
const errorHandler = require('./middleware/errorHandler');
const { ipLimiter } = require('./middleware/rateLimitMiddleware');

// 라우트 임포트
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const subscriptionRoutes = require('./routes/subscriptionRoutes');
const apiKeyRoutes = require('./routes/apiKeyRoutes');
const adminRoutes = require('./routes/adminRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const webhookRoutes = require('./routes/webhookRoutes');

const app = express();

// 미들웨어 설정
app.use(helmet());
app.use(cors({
    origin: process.env.CORS_ORIGIN || '*',
    credentials: true
}));
app.use(morgan('combined'));
app.use(ipLimiter);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// 🔑 프론트엔드 정적 파일 서빙 (중요!)
const frontendPath = path.join(__dirname, './frontend');
app.use(express.static(frontendPath));

// 헬스 체크
app.get('/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// API 라우트
app.use('/api', authRoutes);
app.use('/api', userRoutes);
app.use('/api', subscriptionRoutes);
app.use('/api', apiKeyRoutes);
app.use('/api', adminRoutes);
app.use('/api', dashboardRoutes);
app.use('/api', webhookRoutes);

// 🔑 SPA 라우팅: 모든 GET 요청을 index.html로 리다이렉트 (API 제외)
app.get('*', (req, res) => {
    res.sendFile(path.join(frontendPath, 'index.html'));
});

// 404 처리 (API 요청만)
app.use('/api*', (req, res) => {
    res.status(404).json({
        success: false,
        message: '요청한 엔드포인트를 찾을 수 없습니다'
    });
});

app.use(helmet.contentSecurityPolicy({
    directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "https://cdn.jsdelivr.net"],
        styleSrc: ["'self'", "https://cdn.jsdelivr.net", "'unsafe-inline'"],
        fontSrc: ["'self'", "https://cdn.jsdelivr.net"],
        connectSrc: ["'self'", "https://cdn.jsdelivr.net", "http://localhost:3000"],
        imgSrc: ["'self'", "data:", "https:"],
    }
}));
// 에러 처리
app.use(errorHandler);

// 서버 시작
const PORT = process.env.PORT || 3000;

async function startServer() {
    try {
        // 데이터베이스 연결 초기화
        await initializePool();

        app.listen(PORT, () => {
            console.log(`✅ 서버가 포트 ${PORT}에서 시작되었습니다`);
            console.log(`🌐 프론트엔드 제공 중: http://localhost:${PORT}`);
            console.log(`📡 API 엔드포인트: http://localhost:${PORT}/api`);
            console.log(`환경: ${process.env.NODE_ENV}`);
        });
    } catch (err) {
        console.error('❌ 서버 시작 실패:', err);
        process.exit(1);
    }
}

startServer();

// 프로세스 에러 처리
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
    process.exit(1);
});

module.exports = app;
