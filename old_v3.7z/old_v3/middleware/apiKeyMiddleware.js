const apiKeyService = require('../services/apiKeyService');
const subscriptionService = require('../services/subscriptionService');
const errorResponse = require('../utils/errorResponse');
const { executeNonQuery, executeQuery } = require('../config/database');

async function validateApiKeyMiddleware(req, res, next) {
    try {
        const apiKey = req.headers['x-api-key'];
        const apiSecret = req.headers['x-api-secret'];
        
        if (!apiKey || !apiSecret) {
            return errorResponse(res, 'API Key와 Secret이 필요합니다', 401, 'MISSING_CREDENTIALS');
        }
        
        // API Key 검증
        const keyInfo = await apiKeyService.validateApiKey(apiKey, apiSecret);
        
        if (!keyInfo) {
            return errorResponse(res, '유효하지 않은 API Key입니다', 401, 'INVALID_API_KEY');
        }
        
        // 사용자 활성화 상태 확인
        const users = await executeQuery(
            'SELECT is_active, is_blocked FROM [Users] WHERE id = @userId',
            { userId: keyInfo.user_id }
        );
        
        if (users.length === 0 || !users.is_active || users.is_blocked) {
            return errorResponse(res, '사용자 계정이 비활성화되었습니다', 403, 'USER_BLOCKED');
        }
        
        // 구독 활성화 상태 확인
        const isSubscriptionActive = await subscriptionService.isSubscriptionActive(keyInfo.user_id);
        
        if (!isSubscriptionActive) {
            return errorResponse(res, '활성화된 구독이 없습니다', 403, 'SUBSCRIPTION_INACTIVE');
        }
        
        // Rate Limit 확인
        const monthlyUsage = await executeQuery(
            `SELECT total_requests FROM [MonthlyUsage]
             WHERE api_key_id = @keyId
             AND YEAR(GETDATE()) = year
             AND MONTH(GETDATE()) = month`,
            { keyId: keyInfo.id }
        );
        
        let currentUsage = 0;
        if (monthlyUsage.length > 0) {
            currentUsage = monthlyUsage.total_requests;
        }
        
        // 구독 제한 확인
        const subscription = await subscriptionService.getUserSubscription(keyInfo.user_id);
        
        if (currentUsage >= subscription.api_call_limit) {
            return errorResponse(res, 'API 호출 제한을 초과했습니다', 429, 'API_LIMIT_EXCEEDED');
        }
        
        // 요청 정보 저장
        req.apiKeyInfo = keyInfo;
        req.currentUsage = currentUsage;
        req.usageLimit = subscription.api_call_limit;
        
        next();
    } catch (err) {
        errorResponse(res, err.message, 500);
    }
}

module.exports = { validateApiKeyMiddleware };
