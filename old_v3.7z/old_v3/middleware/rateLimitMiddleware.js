const rateLimit = require('express-rate-limit');
const { executeQuery } = require('../config/database');
const { RATE_LIMIT_TYPE } = require('../config/constants');

// IP 기반 Rate Limiting
const ipLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1시간
    max: 100,
    message: 'IP 주소당 시간 제한을 초과했습니다',
    standardHeaders: true,
    legacyHeaders: false,
});

// API Key 기반 Rate Limiting
async function apiKeyRateLimiter(req, res, next) {
    try {
        const apiKey = req.headers['x-api-key'];
        
        if (!apiKey) {
            return next();
        }
        
        const now = new Date();
        const oneHourAgo = new Date(now - 60 * 60 * 1000);
        
        // API Key 관련 최근 요청 수 확인
        const result = await executeQuery(
            `SELECT COUNT(*) as count FROM [ApiLogs] 
             WHERE api_key = @apiKey AND created_at > @oneHourAgo`,
            { apiKey, oneHourAgo }
        );
        
        const requestCount = result.count;
        
        // 제한 초과 확인 (예: 1000요청/시간)
        if (requestCount > 1000) {
            return res.status(429).json({
                success: false,
                message: 'Rate limit exceeded',
                retryAfter: 3600
            });
        }
        
        next();
    } catch (err) {
        console.error('Rate limit check error:', err);
        next();
    }
}

module.exports = {
    ipLimiter,
    apiKeyRateLimiter
};
