// utils.js - 브라우저 호환 버전 (UI 유틸리티)
// IIFE 패턴으로 캡슐화

(function() {
    'use strict';

    const UI = {
        /**
         * Toast 메시지 표시
         */
        showToast(message, type = 'info') {
            const toastContainer = document.getElementById('toast-container');
            
            if (!toastContainer) {
                console.warn('Toast container not found');
                alert(message);
                return;
            }

            const toast = document.createElement('div');
            toast.className = `toast alert alert-${type}`;
            toast.setAttribute('role', 'alert');
            toast.textContent = message;

            toastContainer.appendChild(toast);

            // 3초 후 자동 제거
            setTimeout(() => {
                toast.remove();
            }, 3000);
        },

        /**
         * 로딩 스피너 표시
         */
        showLoader(show = true) {
            const loader = document.getElementById('loader');
            if (loader) {
                loader.style.display = show ? 'block' : 'none';
            }
        },

        /**
         * 모달 표시
         */
        showModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'block';
                // Bootstrap 모달 사용 시
                if (window.bootstrap) {
                    const bsModal = new window.bootstrap.Modal(modal);
                    bsModal.show();
                }
            }
        },

        /**
         * 모달 숨김
         */
        hideModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'none';
                // Bootstrap 모달 사용 시
                if (window.bootstrap) {
                    const bsModal = window.bootstrap.Modal.getInstance(modal);
                    if (bsModal) {
                        bsModal.hide();
                    }
                }
            }
        },

        /**
         * 확인 대화상자 표시
         */
        showConfirm(message, onConfirm, onCancel) {
            if (confirm(message)) {
                onConfirm && onConfirm();
            } else {
                onCancel && onCancel();
            }
        },

        /**
         * 요소 비활성화/활성화
         */
        setDisabled(elementId, disabled = true) {
            const element = document.getElementById(elementId);
            if (element) {
                element.disabled = disabled;
            }
        },

        /**
         * 요소 내용 업데이트
         */
        setText(elementId, text) {
            const element = document.getElementById(elementId);
            if (element) {
                element.textContent = text;
            }
        },

        /**
         * 요소 HTML 업데이트
         */
        setHTML(elementId, html) {
            const element = document.getElementById(elementId);
            if (element) {
                element.innerHTML = html;
            }
        },

        /**
         * 요소 클래스 추가
         */
        addClass(elementId, className) {
            const element = document.getElementById(elementId);
            if (element) {
                element.classList.add(className);
            }
        },

        /**
         * 요소 클래스 제거
         */
        removeClass(elementId, className) {
            const element = document.getElementById(elementId);
            if (element) {
                element.classList.remove(className);
            }
        },

        /**
         * 페이지 리다이렉트
         */
        redirect(url) {
            window.location.href = url;
        },

        /**
         * 이벤트 리스너 설정
         */
        addEventListener(elementId, eventType, handler) {
            const element = document.getElementById(elementId);
            if (element) {
                element.addEventListener(eventType, handler);
            }
        }
    };

    // 전역 네임스페이스에 노출
    window.UI = UI;

})();

/**
 
// assets/js/utils.js

/**
 * Toast 메시지 표시
 */
// function showToast(message, type = 'info') {
//     const toastHTML = `
//         <div class="toast" role="alert">
//             <div class="toast-header bg-${type} text-white">
//                 <strong class="me-auto">${type === 'error' ? '오류' : '알림'}</strong>
//                 <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
//             </div>
//             <div class="toast-body">${message}</div>
//         </div>
//     `;

//     const toastContainer = document.getElementById('toast-container') || createToastContainer();
//     const toastElement = document.createElement('div');
//     toastElement.innerHTML = toastHTML;
//     toastContainer.appendChild(toastElement);

//     const toast = new bootstrap.Toast(toastElement.querySelector('.toast'));
//     toast.show();

//     setTimeout(() => {
//         toastElement.remove();
//     }, 5000);
// }

// /**
//  * Toast 컨테이너 생성
//  */
// function createToastContainer() {
//     const container = document.createElement('div');
//     container.id = 'toast-container';
//     container.className = 'toast-container position-fixed top-0 end-0 p-3';
//     document.body.appendChild(container);
//     return container;
// }

// /**
//  * 로딩 스피너 표시
//  */
// function showLoading() {
//     const spinner = document.getElementById('loading-spinner');
//     if (spinner) spinner.style.display = 'flex';
// }

// function hideLoading() {
//     const spinner = document.getElementById('loading-spinner');
//     if (spinner) spinner.style.display = 'none';
// }

// /**
//  * 모달 표시
//  */
// function showModal(modalId) {
//     const modal = new bootstrap.Modal(document.getElementById(modalId));
//     modal.show();
// }

// function hideModal(modalId) {
//     const modal = bootstrap.Modal.getInstance(document.getElementById(modalId));
//     if (modal) modal.hide();
// }

// /**
//  * 날짜 포맷팅
//  */
// function formatDate(dateString) {
//     const date = new Date(dateString);
//     return date.toLocaleDateString('ko-KR', {
//         year: 'numeric',
//         month: '2-digit',
//         day: '2-digit'
//     });
// }

// function formatDateTime(dateString) {
//     const date = new Date(dateString);
//     return date.toLocaleDateString('ko-KR', {
//         year: 'numeric',
//         month: '2-digit',
//         day: '2-digit',
//         hour: '2-digit',
//         minute: '2-digit',
//         second: '2-digit'
//     });
// }

// /**
//  * 숫자 포맷팅
//  */
// function formatNumber(num) {
//     return new Intl.NumberFormat('ko-KR').format(num);
// }

// /**
//  * 테이블 페이지네이션
//  */
// function setupPagination(totalItems, itemsPerPage, currentPage, onPageChange) {
//     const totalPages = Math.ceil(totalItems / itemsPerPage);
    
//     let html = '<nav><ul class="pagination justify-content-center">';
    
//     // 이전 페이지
//     if (currentPage > 1) {
//         html += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}">이전</a></li>`;
//     }
    
//     // 페이지 번호
//     for (let i = 1; i <= totalPages; i++) {
//         if (i === currentPage) {
//             html += `<li class="page-item active"><span class="page-link">${i}</span></li>`;
//         } else {
//             html += `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
//         }
//     }
    
//     // 다음 페이지
//     if (currentPage < totalPages) {
//         html += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}">다음</a></li>`;
//     }
    
//     html += '</ul></nav>';
    
//     const container = document.getElementById('pagination');
//     if (container) {
//         container.innerHTML = html;
//         container.querySelectorAll('.page-link').forEach(link => {
//             link.addEventListener('click', (e) => {
//                 e.preventDefault();
//                 const page = parseInt(link.dataset.page);
//                 onPageChange(page);
//             });
//         });
//     }
// }

// /**
//  * 텍스트 복사
//  */
// async function copyToClipboard(text) {
//     try {
//         await navigator.clipboard.writeText(text);
//         showToast('복사되었습니다', 'success');
//     } catch (err) {
//         showToast('복사 실패', 'error');
//     }
// }

// /**
//  * API 키 마스킹
//  */
// function maskApiKey(key) {
//     if (key.length <= 10) return key;
//     return key.substring(0, 10) + '***';
// }

// /**
//  * 상태 배지 색상
//  */
// function getStatusBadgeClass(status) {
//     const statusMap = {
//         'active': 'success',
//         'pending': 'warning',
//         'expired': 'danger',
//         'cancelled': 'secondary',
//         'blocked': 'danger',
//         'inactive': 'secondary'
//     };
//     return statusMap[status] || 'secondary';
// }

// export {
//     showToast,
//     showLoading,
//     hideLoading,
//     showModal,
//     hideModal,
//     formatDate,
//     formatDateTime,
//     formatNumber,
//     setupPagination,
//     copyToClipboard,
//     maskApiKey,
//     getStatusBadgeClass
// };


// */