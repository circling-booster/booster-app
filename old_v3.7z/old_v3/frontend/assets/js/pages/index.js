// index.js - 홈 페이지 로직
// 브라우저 호환 버전

(function() {
    'use strict';

    // DOM 준비 완료 시 실행
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        console.log('Index page initialized');
        
        // 네비게이션 업데이트 (로그인 상태 확인)
        updateNavigation();
        
        // 스크롤 애니메이션
        setupScrollAnimations();
    }

    function updateNavigation() {
        const isAuthenticated = window.AuthManager && window.AuthManager.isAuthenticated();
        const authLinks = document.getElementById('authLinks');
        const dashboardLink = document.getElementById('dashboardLink');

        if (isAuthenticated) {
            // 로그인된 상태
            if (authLinks) {
                authLinks.style.display = 'none';
            }
            if (dashboardLink) {
                dashboardLink.style.display = 'block';
            }

            // 사용자 정보 표시 (옵션)
            const user = window.AuthManager.getUserInfo();
            if (user) {
                console.log('Welcome:', user.firstName, user.lastName);
            }

            // 로그아웃 버튼 추가
            const navbarNav = document.querySelector('.navbar-nav');
            if (navbarNav && !document.getElementById('logoutLink')) {
                const logoutItem = document.createElement('li');
                logoutItem.className = 'nav-item';
                logoutItem.id = 'logoutLink';
                logoutItem.innerHTML = `
                    <a class="nav-link" href="#" onclick="handleLogout(event)">로그아웃</a>
                `;
                navbarNav.appendChild(logoutItem);

                // 전역 함수로 등록
                window.handleLogout = function(e) {
                    e.preventDefault();
                    if (window.AuthManager) {
                        window.AuthManager.logout();
                    }
                };
            }
        } else {
            // 미로그인 상태
            if (authLinks) {
                authLinks.style.display = 'block';
            }
            if (dashboardLink) {
                dashboardLink.style.display = 'none';
            }
        }
    }

    function setupScrollAnimations() {
        // 스크롤 시 카드 애니메이션 (옵션)
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, {
            threshold: 0.1
        });

        // 모든 카드 대상으로 옵저버 설정
        document.querySelectorAll('.feature-card, .tier-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
    }

})();