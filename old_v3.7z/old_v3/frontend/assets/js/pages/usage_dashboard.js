// usage_dashboard.js - 사용 현황 대시보드 로직
// 브라우저 호환 버전

(function() {
    'use strict';

    let monthlyChart = null;
    let statusCodeChart = null;
    let apiKeyUsageChart = null;
    let currentLogPage = 1;

    // DOM 준비 완료 시 실행
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        console.log('Usage dashboard page initialized');
        
        // 인증 확인
        if (!window.AuthManager || !window.AuthManager.checkAuthentication()) {
            return;
        }

        // 데이터 로드
        loadDashboardData();
        
        // 이벤트 리스너 설정
        setupEventHandlers();
    }

    async function loadDashboardData() {
        try {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            // 통계 데이터 조회
            const stats = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.DASHBOARD.STATS
            );

            // 대시보드 통계 표시
            displayStats(stats);

            // API 로그 조회
            const logs = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.DASHBOARD.LOGS,
                { page: 1, limit: 10 }
            );

            // 로그 표시
            if (logs && logs.data) {
                displayLogs(logs.data);
            }

            // API 키 목록 조회
            const apiKeys = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.API_KEYS.LIST
            );

            // API 키 표시
            if (apiKeys) {
                displayApiKeys(apiKeys);
            }

            // 차트 생성
            createCharts(stats);

        } catch (err) {
            console.error('Dashboard load error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('대시보드 데이터를 로드할 수 없습니다', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    function displayStats(stats) {
        const totalCalls = stats.currentUsage || 0;
        const limit = stats.usageLimit || 1000;
        const remainingCalls = Math.max(0, limit - totalCalls);
        const percentage = Math.round((totalCalls / limit) * 100);

        // 통계 표시
        document.getElementById('totalCalls').textContent = formatNumber(totalCalls);
        document.getElementById('remainingCalls').textContent = formatNumber(remainingCalls);
        document.getElementById('usagePercentage').textContent = `${percentage}%`;
        document.getElementById('activeKeys').textContent = stats.activeApiKeys || 0;

        // 프로그레스 바 업데이트
        const usageBar = document.getElementById('usageBar');
        if (usageBar) {
            usageBar.style.width = `${Math.min(100, percentage)}%`;
            
            // 상태에 따라 색상 변경
            usageBar.className = 'progress-bar';
            if (percentage >= 90) {
                usageBar.classList.add('bg-danger');
            } else if (percentage >= 70) {
                usageBar.classList.add('bg-warning');
            } else {
                usageBar.classList.add('bg-success');
            }
            
            document.getElementById('usageText').textContent = `${percentage}%`;
        }

        document.getElementById('usageDetail').textContent = `${formatNumber(totalCalls)} / ${formatNumber(limit)} 호출 사용`;
    }

    function displayLogs(logs) {
        const logsList = document.getElementById('logsList');
        if (!logsList) return;

        if (!logs || logs.length === 0) {
            logsList.innerHTML = '<tr><td colspan="5" class="text-center text-muted">로그가 없습니다</td></tr>';
            return;
        }

        const logsHTML = logs.map(log => `
            <tr>
                <td>${formatDateTime(log.timestamp)}</td>
                <td><small>${log.endpoint}</small></td>
                <td><span class="badge bg-info">${log.method}</span></td>
                <td>${getStatusBadge(log.statusCode)}</td>
                <td>${log.responseTime}ms</td>
            </tr>
        `).join('');

        logsList.innerHTML = logsHTML;
    }

    function displayApiKeys(apiKeys) {
        const apiKeysList = document.getElementById('apiKeysList');
        if (!apiKeysList) return;

        if (!apiKeys || apiKeys.length === 0) {
            apiKeysList.innerHTML = '<tr><td colspan="6" class="text-center text-muted">API 키가 없습니다</td></tr>';
            return;
        }

        const keysHTML = apiKeys.map(key => `
            <tr>
                <td>${key.keyName}</td>
                <td>
                    <span class="font-monospace">${maskApiKey(key.apiKey)}</span>
                    <button class="btn btn-sm btn-outline-secondary ms-2" onclick="copyToClipboard('${key.apiKey}')">
                        복사
                    </button>
                </td>
                <td>${formatDate(key.createdAt)}</td>
                <td>${key.lastUsed ? formatDateTime(key.lastUsed) : '-'}</td>
                <td>
                    <span class="badge ${key.isActive ? 'badge-status-active' : 'badge-status-inactive'}">
                        ${key.isActive ? '활성' : '비활성'}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="revokeApiKey('${key.id}')">
                        삭제
                    </button>
                </td>
            </tr>
        `).join('');

        apiKeysList.innerHTML = keysHTML;
    }

    function createCharts(stats) {
        // 월별 API 호출 차트
        createMonthlyChart(stats);

        // 상태 코드 분포 차트
        createStatusChart(stats);

        // API 키별 사용량 차트
        createApiKeyChart(stats);
    }

    function createMonthlyChart(stats) {
        const ctx = document.getElementById('monthlyChart');
        if (!ctx) return;

        // 기존 차트 제거
        if (monthlyChart) {
            monthlyChart.destroy();
        }

        const monthLabels = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'];
        const mockData = stats.monthlyData || [100, 200, 150, 300, 250, 400, 350, 450, 500, 480, 520, stats.currentUsage || 600];

        monthlyChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: monthLabels,
                datasets: [{
                    label: 'API 호출',
                    data: mockData,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.3,
                    fill: true,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function createStatusChart(stats) {
        const ctx = document.getElementById('statusCodeChart');
        if (!ctx) return;

        // 기존 차트 제거
        if (statusCodeChart) {
            statusCodeChart.destroy();
        }

        const statusData = [
            stats.status200 || 8500,
            stats.status400 || 150,
            stats.status401 || 50,
            stats.status500 || 10
        ];

        statusCodeChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['200 OK', '400 Bad Request', '401 Unauthorized', '500 Error'],
                datasets: [{
                    data: statusData,
                    backgroundColor: [
                        '#28a745',
                        '#ffc107',
                        '#fd7e14',
                        '#dc3545'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    function createApiKeyChart(stats) {
        const ctx = document.getElementById('apiKeyUsageChart');
        if (!ctx) return;

        // 기존 차트 제거
        if (apiKeyUsageChart) {
            apiKeyUsageChart.destroy();
        }

        const apiKeyData = stats.apiKeyUsage || [
            { name: 'API Key 1', calls: 3000 },
            { name: 'API Key 2', calls: 2500 },
            { name: 'API Key 3', calls: 1500 },
            { name: 'API Key 4', calls: 1000 }
        ];

        const labels = apiKeyData.map(k => k.name);
        const data = apiKeyData.map(k => k.calls);

        apiKeyUsageChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'API 호출 수',
                    data: data,
                    backgroundColor: '#667eea'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function setupEventHandlers() {
        // 탭 버튼 클릭 이벤트
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const tabName = button.dataset.tab;
                switchTab(tabName);
            });
        });

        // 로그아웃 버튼
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (window.AuthManager) {
                    window.AuthManager.logout();
                }
            });
        }

        // API 키 생성 폼
        const createKeyForm = document.getElementById('createKeyForm');
        if (createKeyForm) {
            createKeyForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                await createApiKey();
            });
        }
    }

    function switchTab(tabName) {
        // 탭 버튼 업데이트
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // 탭 콘텐츠 업데이트
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(tabName).classList.add('active');
    }

    async function createApiKey() {
        try {
            const keyName = document.getElementById('keyName').value.trim();

            if (!keyName) {
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('키 이름을 입력하세요', 'error');
                }
                return;
            }

            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            const response = await window.ApiClient.post(
                window.AppConfig.ENDPOINTS.API_KEYS.CREATE,
                { keyName }
            );

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('API 키가 생성되었습니다', 'success');
            }

            // 모달 닫기
            const modal = document.getElementById('createKeyModal');
            if (modal) {
                const bsModal = window.bootstrap.Modal.getInstance(modal);
                if (bsModal) {
                    bsModal.hide();
                }
            }

            // 폼 초기화
            document.getElementById('createKeyForm').reset();

            // 목록 새로고침
            loadDashboardData();

        } catch (err) {
            console.error('API key creation error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('API 키 생성 실패', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    // 전역 함수들
    window.revokeApiKey = async function(keyId) {
        if (!confirm('정말 이 API 키를 삭제하시겠습니까?')) {
            return;
        }

        try {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            const endpoint = window.AppConfig.ENDPOINTS.API_KEYS.REVOKE.replace('{keyId}', keyId);
            await window.ApiClient.delete(endpoint);

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('API 키가 삭제되었습니다', 'success');
            }

            loadDashboardData();

        } catch (err) {
            console.error('API key revocation error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('API 키 삭제 실패', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    };

    window.copyToClipboard = async function(text) {
        try {
            await navigator.clipboard.writeText(text);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('복사되었습니다', 'success');
            }
        } catch (err) {
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('복사 실패', 'error');
            }
        }
    };

    window.handleCreateApiKey = function() {
        const form = document.getElementById('createKeyForm');
        const event = new Event('submit');
        form.dispatchEvent(event);
    };

    // 헬퍼 함수들
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ko-KR');
    }

    function formatDateTime(dateString) {
        const date = new Date(dateString);
        return date.toLocaleString('ko-KR', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    function formatNumber(num) {
        return new Intl.NumberFormat('ko-KR').format(num);
    }

    function maskApiKey(key) {
        if (key.length <= 10) return key;
        return key.substring(0, 10) + '***';
    }

    function getStatusBadge(statusCode) {
        let badgeClass = 'bg-success';
        if (statusCode >= 400 && statusCode < 500) {
            badgeClass = 'bg-warning';
        } else if (statusCode >= 500) {
            badgeClass = 'bg-danger';
        }
        return `<span class="badge ${badgeClass}">${statusCode}</span>`;
    }

})();