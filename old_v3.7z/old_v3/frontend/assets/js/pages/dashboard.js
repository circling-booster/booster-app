// dashboard.js - 대시보드 페이지 로직
// HTML의 마지막 <script> 태그로 로드되어야 함

(function() {
    'use strict';

    // DOM 준비 완료 시 실행
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        console.log('Dashboard page initialized');
        
        // 인증 확인
        if (!window.AuthManager || !window.AuthManager.checkAuthentication()) {
            return;
        }

        // 사용자 정보 표시
        displayUserInfo();
        
        // 대시보드 데이터 로드
        loadDashboardData();
        
        // 이벤트 리스너 설정
        setupEventHandlers();
    }

    function displayUserInfo() {
        const user = window.AuthManager.getUserInfo();
        if (user) {
            const userNameElement = document.getElementById('userName');
            if (userNameElement) {
                userNameElement.textContent = `${user.firstName} ${user.lastName}`;
            }
        }
    }

    async function loadDashboardData() {
        try {
            if (!window.ApiClient) {
                console.error('ApiClient not loaded');
                return;
            }

            // 로딩 표시
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            // 대시보드 통계 조회
            const stats = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.DASHBOARD.STATS
            );

            // 데이터 표시
            displayStats(stats);

            // API 로그 조회
            const logs = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.DASHBOARD.LOGS,
                { page: 1, limit: 10 }
            );

            displayLogs(logs);

        } catch (err) {
            console.error('Dashboard data load error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('대시보드 데이터를 로드할 수 없습니다', 'error');
            }
        } finally {
            // 로딩 숨김
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    function displayStats(stats) {
        // 통계 데이터를 DOM에 표시
        const elements = {
            totalApiCalls: 'totalApiCalls',
            currentUsage: 'currentUsage',
            usageLimit: 'usageLimit',
            remainingCalls: 'remainingCalls'
        };

        for (const [key, elementId] of Object.entries(elements)) {
            const element = document.getElementById(elementId);
            if (element && stats[key] !== undefined) {
                element.textContent = stats[key];
            }
        }

        // 사용률 프로그레스 바 업데이트
        updateProgressBar(stats);
    }

    function updateProgressBar(stats) {
        if (!stats.currentUsage || !stats.usageLimit) return;

        const percentage = (stats.currentUsage / stats.usageLimit) * 100;
        const progressBar = document.getElementById('usageProgressBar');
        
        if (progressBar) {
            progressBar.style.width = percentage + '%';
            
            // 상태에 따라 색상 변경
            progressBar.className = 'progress-bar';
            if (percentage >= 80) {
                progressBar.classList.add('bg-danger');
            } else if (percentage >= 50) {
                progressBar.classList.add('bg-warning');
            } else {
                progressBar.classList.add('bg-success');
            }
        }
    }

    function displayLogs(logs) {
        const logsContainer = document.getElementById('logsContainer');
        if (!logsContainer) return;

        if (!logs || logs.length === 0) {
            logsContainer.innerHTML = '<p>기록이 없습니다</p>';
            return;
        }

        const logsHTML = logs.map(log => `
            <tr>
                <td>${new Date(log.timestamp).toLocaleString('ko-KR')}</td>
                <td>${log.endpoint}</td>
                <td><span class="badge bg-${getStatusBadgeColor(log.status)}">${log.status}</span></td>
                <td>${log.responseTime}ms</td>
            </tr>
        `).join('');

        logsContainer.innerHTML = logsHTML;
    }

    function getStatusBadgeColor(status) {
        if (status >= 200 && status < 300) return 'success';
        if (status >= 300 && status < 400) return 'info';
        if (status >= 400 && status < 500) return 'warning';
        return 'danger';
    }

    function setupEventHandlers() {
        // 로그아웃 버튼
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (window.AuthManager) {
                    window.AuthManager.logout();
                }
            });
        }

        // 프로필 수정 버튼
        const editProfileBtn = document.getElementById('editProfileBtn');
        if (editProfileBtn) {
            editProfileBtn.addEventListener('click', () => {
                if (window.UI && window.UI.showModal) {
                    window.UI.showModal('profileModal');
                }
            });
        }

        // 프로필 저장 버튼
        const saveProfileBtn = document.getElementById('saveProfileBtn');
        if (saveProfileBtn) {
            saveProfileBtn.addEventListener('click', async () => {
                await updateProfile();
            });
        }

        // 새로고침 버튼
        const refreshBtn = document.getElementById('refreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                loadDashboardData();
            });
        }
    }

    async function updateProfile() {
        try {
            const firstName = document.getElementById('editFirstName').value.trim();
            const lastName = document.getElementById('editLastName').value.trim();
            const phone = document.getElementById('editPhone').value.trim();

            if (!firstName || !lastName) {
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('이름은 필수입니다', 'error');
                }
                return;
            }

            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            const response = await window.ApiClient.put(
                window.AppConfig.ENDPOINTS.USER.UPDATE_PROFILE,
                {
                    firstName,
                    lastName,
                    phoneNumber: phone
                }
            );

            // 사용자 정보 업데이트
            window.AuthManager.setUserInfo(response);
            displayUserInfo();

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('프로필이 업데이트되었습니다', 'success');
            }

            // 모달 닫기
            if (window.UI && window.UI.hideModal) {
                window.UI.hideModal('profileModal');
            }

        } catch (err) {
            console.error('Profile update error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('프로필 업데이트 실패', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

})();