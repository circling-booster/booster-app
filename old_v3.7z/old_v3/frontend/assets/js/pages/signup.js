
(function() {
    'use strict';

    // ============================================================
    // DOM 준비 완료 확인 - 중요!
    // ============================================================
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // ============================================================
    // 초기화 함수
    // ============================================================
    function init() {
        console.log('Signup page initialized');
        
        try {
            // 인증 확인 - 이미 로그인했으면 대시보드로 이동
            if (window.AuthManager && window.AuthManager.isAuthenticated()) {
                window.location.href = '/pages/dashboard.html';
                return;
            }

            // 폼 핸들러 설정
            setupFormHandlers();

        } catch (err) {
            console.error('Initialization error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('페이지 초기화 실패', 'error');
            }
        }
    }

    // ============================================================
    // 폼 이벤트 핸들러 설정
    // ============================================================
    function setupFormHandlers() {
        const signupForm = document.getElementById('signupForm');
        
        // Null 체크 - 오류 3 해결
        if (!signupForm) {
            console.error('❌ signupForm 요소를 찾을 수 없습니다');
            console.error('HTML에서 id="signupForm"이 있는지 확인하세요');
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('폼 로드 실패: signupForm을 찾을 수 없습니다', 'error');
            }
            return;
        }

        // 폼 제출 이벤트
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleSignup();
        });

        // 비밀번호 필드 실시간 검증 (선택사항)
        const passwordField = document.getElementById('password');
        const confirmPasswordField = document.getElementById('confirmPassword');

        if (passwordField) {
            passwordField.addEventListener('blur', function() {
                validatePasswordField();
            });
        }

        if (confirmPasswordField) {
            confirmPasswordField.addEventListener('blur', function() {
                validateConfirmPasswordField();
            });
        }

        console.log('✅ 폼 핸들러 설정 완료');
    }

    // ============================================================
    // 필드 값 안전하게 가져오기 (Null 참조 오류 예방)
    // ============================================================
    function getFieldValue(fieldId, fieldName) {
        try {
            const element = document.getElementById(fieldId);
            
            // Null 체크
            if (!element) {
                const errorMsg = `필드를 찾을 수 없습니다: #${fieldId}`;
                console.error('❌', errorMsg);
                throw new Error(errorMsg);
            }

            // value 속성 확인
            if (typeof element.value === 'undefined') {
                const errorMsg = `요소가 값을 가지지 않습니다: #${fieldId}`;
                console.error('❌', errorMsg);
                throw new Error(errorMsg);
            }

            const value = element.value.trim();
            console.log(`✅ ${fieldName}: 로드 완료 (길이: ${value.length})`);
            return value;

        } catch (err) {
            console.error(`필드 로드 실패 (${fieldId}):`, err.message);
            throw err;
        }
    }

    // ============================================================
    // 폼 데이터 수집
    // ============================================================
    function collectFormData() {
        try {
            const formData = {
                firstName: getFieldValue('firstName', '이름'),
                lastName: getFieldValue('lastName', '성'),
                email: getFieldValue('email', '이메일'),
                phoneNumber: getFieldValue('phone', '휴대폰'),
                password: getFieldValue('password', '비밀번호'),
                confirmPassword: getFieldValue('confirmPassword', '비밀번호 확인')
            };

            console.log('📋 폼 데이터 수집 완료:', {
                firstName: formData.firstName,
                lastName: formData.lastName,
                email: formData.email,
                phoneNumber: formData.phoneNumber,
                password: '***' // 보안상 표시하지 않음
            });

            return formData;

        } catch (err) {
            console.error('폼 데이터 수집 실패:', err);
            throw err;
        }
    }

    // ============================================================
    // 비밀번호 필드 검증
    // ============================================================
    function validatePasswordField() {
        try {
            const passwordField = document.getElementById('password');
            if (!passwordField) return;

            const password = passwordField.value;
            const passwordError = document.getElementById('passwordError');

            if (!password) {
                if (passwordError) passwordError.textContent = '비밀번호를 입력하세요';
                return false;
            }

            if (window.Validation && window.Validation.ValidationRules) {
                const error = window.Validation.ValidationRules.password(password);
                if (error && passwordError) {
                    passwordError.textContent = error;
                    return false;
                }
            }

            if (passwordError) passwordError.textContent = '';
            return true;

        } catch (err) {
            console.error('비밀번호 검증 오류:', err);
            return false;
        }
    }

    // ============================================================
    // 확인 비밀번호 필드 검증
    // ============================================================
    function validateConfirmPasswordField() {
        try {
            const passwordField = document.getElementById('password');
            const confirmPasswordField = document.getElementById('confirmPassword');
            const confirmPasswordError = document.getElementById('confirmPasswordError');

            if (!passwordField || !confirmPasswordField) return;

            if (passwordField.value !== confirmPasswordField.value) {
                if (confirmPasswordError) {
                    confirmPasswordError.textContent = '비밀번호가 일치하지 않습니다';
                }
                return false;
            }

            if (confirmPasswordError) confirmPasswordError.textContent = '';
            return true;

        } catch (err) {
            console.error('확인 비밀번호 검증 오류:', err);
            return false;
        }
    }

    // ============================================================
    // 메인 회원가입 함수
    // ============================================================
    async function handleSignup() {
        try {
            console.log('📝 회원가입 시작...');

            // Step 1: 폼 데이터 수집
            let formData;
            try {
                formData = collectFormData();
            } catch (err) {
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('필수 필드를 모두 입력하세요', 'error');
                }
                return;
            }

            // Step 2: 클라이언트 측 검증
            if (!window.Validation || !window.Validation.validateForm) {
                console.warn('⚠️ Validation 모듈을 찾을 수 없습니다');
            } else {
                const isValid = window.Validation.validateForm('signupForm', {
                    firstName: 'name',
                    lastName: 'name',
                    email: 'email',
                    phone: 'phone',
                    password: 'password'
                });

                if (!isValid) {
                    console.log('❌ 검증 실패');
                    return;
                }
            }

            // Step 3: 비밀번호 일치 확인
            if (formData.password !== formData.confirmPassword) {
                console.log('❌ 비밀번호 불일치');
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('비밀번호가 일치하지 않습니다', 'error');
                }
                return;
            }

            // Step 4: 로딩 표시
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            // Step 5: API 클라이언트 확인
            if (!window.ApiClient) {
                throw new Error('ApiClient를 로드할 수 없습니다');
            }

            if (!window.AppConfig || !window.AppConfig.ENDPOINTS) {
                throw new Error('AppConfig를 로드할 수 없습니다');
            }

            // Step 6: API 호출
            console.log('🌐 API 호출 중...');
            const endpoint = window.AppConfig.ENDPOINTS.AUTH.SIGNUP;
            console.log('📍 엔드포인트:', endpoint);

            const response = await window.ApiClient.post(endpoint, {
                firstName: formData.firstName,
                lastName: formData.lastName,
                email: formData.email,
                phoneNumber: formData.phoneNumber,
                password: formData.password
            });

            console.log('✅ API 응답:', response);

            // Step 7: 성공 메시지
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('회원가입 성공! 로그인 페이지로 이동합니다.', 'success');
            }

            // Step 8: 리다이렉트
            setTimeout(function() {
                window.location.href = '/pages/auth/login.html';
            }, 1500);

        } catch (err) {
            console.error('❌ 회원가입 오류:', err);
            
            let errorMessage = '회원가입 실패';
            
            if (err.message) {
                errorMessage = err.message;
            } else if (typeof err === 'string') {
                errorMessage = err;
            }

            if (window.UI && window.UI.showToast) {
                window.UI.showToast(errorMessage, 'error');
            }

        } finally {
            // 로딩 숨김
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    // ============================================================
    // 전역 함수로 노출 (HTML에서 호출 가능)
    // ============================================================
    window.handleSignup = handleSignup;
    window.getFieldValue = getFieldValue;

})();