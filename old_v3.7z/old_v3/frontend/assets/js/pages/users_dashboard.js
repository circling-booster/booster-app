// users_dashboard.js - 사용자 관리 대시보드 로직 (관리자용)
// 브라우저 호환 버전

(function() {
    'use strict';

    let currentUserPage = 1;
    let currentUser = null;

    // DOM 준비 완료 시 실행
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        console.log('Users dashboard page initialized');
        
        // 인증 확인 (관리자 권한 필수)
        if (!window.AuthManager || !window.AuthManager.checkAuthentication('admin')) {
            return;
        }

        // 데이터 로드
        loadDashboardData();
        
        // 이벤트 리스너 설정
        setupEventHandlers();
    }

    async function loadDashboardData() {
        try {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            // 관리자 통계 조회
            const stats = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.ADMIN.STATS
            );

            displayStats(stats);

            // 사용자 목록 로드
            await loadUsersList();

            // 대기 중인 구독 로드
            await loadPendingSubscriptions();

        } catch (err) {
            console.error('Dashboard load error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('대시보드 데이터를 로드할 수 없습니다', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    function displayStats(stats) {
        document.getElementById('totalUsers').textContent = stats.totalUsers || 0;
        document.getElementById('activeUsers').textContent = stats.activeUsers || 0;
        document.getElementById('blockedUsers').textContent = stats.blockedUsers || 0;
        document.getElementById('pendingSubscriptions').textContent = stats.pendingSubscriptions || 0;
    }

    async function loadUsersList(page = 1) {
        try {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            const searchQuery = document.getElementById('searchInput').value;
            const statusFilter = document.getElementById('statusFilter').value;

            const params = {
                page,
                limit: 10,
                search: searchQuery || undefined,
                status: statusFilter || undefined
            };

            const response = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.ADMIN.USERS_LIST,
                params
            );

            if (response && response.users) {
                displayUsersList(response.users);
                
                // 페이지네이션 설정
                if (window.Pagination) {
                    window.Pagination.setupPagination(
                        response.total,
                        response.limit,
                        response.page,
                        (newPage) => loadUsersList(newPage)
                    );
                }
            }

            currentUserPage = page;

        } catch (err) {
            console.error('Users list load error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('사용자 목록을 로드할 수 없습니다', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    function displayUsersList(users) {
        const usersList = document.getElementById('usersList');
        if (!usersList) return;

        if (!users || users.length === 0) {
            usersList.innerHTML = '<tr><td colspan="6" class="text-center text-muted">사용자가 없습니다</td></tr>';
            return;
        }

        const usersHTML = users.map(user => {
            let statusBadge = '';
            if (user.isBlocked) {
                statusBadge = '<span class="badge status-badge-blocked">차단</span>';
            } else if (!user.isActive) {
                statusBadge = '<span class="badge status-badge-pending">비활성</span>';
            } else {
                statusBadge = '<span class="badge status-badge-active">활성</span>';
            }

            return `
                <tr>
                    <td>${user.email}</td>
                    <td>${user.firstName} ${user.lastName}</td>
                    <td>${user.tierName || '-'}</td>
                    <td>${statusBadge}</td>
                    <td>${formatDate(user.createdAt)}</td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="openUserDetail('${user.id}')">
                            상세보기
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="handleUserAction('${user.id}', '${user.isBlocked ? 'unblock' : 'block'}')">
                            ${user.isBlocked ? '차단해제' : '차단'}
                        </button>
                    </td>
                </tr>
            `;
        }).join('');

        usersList.innerHTML = usersHTML;
    }

    async function loadPendingSubscriptions() {
        try {
            const response = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.ADMIN.SUBSCRIPTIONS_PENDING,
                { page: 1, limit: 50 }
            );

            if (response && response.subscriptions) {
                displayPendingSubscriptions(response.subscriptions);
            }

        } catch (err) {
            console.error('Pending subscriptions load error:', err);
        }
    }

    function displayPendingSubscriptions(subscriptions) {
        const subscriptionsList = document.getElementById('subscriptionsList');
        if (!subscriptionsList) return;

        if (!subscriptions || subscriptions.length === 0) {
            subscriptionsList.innerHTML = '<tr><td colspan="5" class="text-center text-muted">대기 중인 구독이 없습니다</td></tr>';
            return;
        }

        const subsHTML = subscriptions.map(sub => `
            <tr>
                <td>${sub.firstName} ${sub.lastName}</td>
                <td>${sub.email}</td>
                <td>${sub.tierName}</td>
                <td>${formatDate(sub.createdAt)}</td>
                <td>
                    <button class="btn btn-sm btn-success" onclick="handleSubscriptionAction('${sub.id}', 'approve')">
                        승인
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="handleSubscriptionAction('${sub.id}', 'reject')">
                        거절
                    </button>
                </td>
            </tr>
        `).join('');

        subscriptionsList.innerHTML = subsHTML;
    }

    function setupEventHandlers() {
        // 탭 버튼
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const tabName = button.dataset.tab;
                switchTab(tabName);
            });
        });

        // 검색 및 필터
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    loadUsersList(1);
                }
            });
        }

        // 상태 필터
        const statusFilter = document.getElementById('statusFilter');
        if (statusFilter) {
            statusFilter.addEventListener('change', () => {
                loadUsersList(1);
            });
        }

        // 로그아웃
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (window.AuthManager) {
                    window.AuthManager.logout();
                }
            });
        }

        // 모달 상태 변경 감시
        const modalStatus = document.getElementById('modalStatus');
        if (modalStatus) {
            modalStatus.addEventListener('change', (e) => {
                const blockReasonDiv = document.getElementById('blockReasonDiv');
                if (e.target.value === 'blocked') {
                    blockReasonDiv.style.display = 'block';
                } else {
                    blockReasonDiv.style.display = 'none';
                }
            });
        }
    }

    function switchTab(tabName) {
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(tabName).classList.add('active');
    }

    // 전역 함수들
    window.openUserDetail = async function(userId) {
        try {
            const users = await window.ApiClient.get(
                `${window.AppConfig.ENDPOINTS.ADMIN.USERS_LIST}/${userId}`
            );

            if (users && users.length > 0) {
                const user = users[0];
                currentUser = user;

                document.getElementById('modalEmail').value = user.email;
                document.getElementById('modalFirstName').value = user.firstName;
                document.getElementById('modalLastName').value = user.lastName;
                document.getElementById('modalSubscription').value = user.tierName || '-';
                document.getElementById('modalJoinDate').value = formatDate(user.createdAt);

                let status = 'active';
                if (user.isBlocked) status = 'blocked';
                else if (!user.isActive) status = 'inactive';
                document.getElementById('modalStatus').value = status;

                // 모달 표시
                const modal = new window.bootstrap.Modal(document.getElementById('userDetailModal'));
                modal.show();
            }

        } catch (err) {
            console.error('User detail load error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('사용자 정보를 로드할 수 없습니다', 'error');
            }
        }
    };

    window.saveUserChanges = async function() {
        try {
            const status = document.getElementById('modalStatus').value;
            const blockReason = document.getElementById('blockReason').value;

            if (!currentUser) return;

            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            if (status === 'blocked') {
                // 사용자 차단
                const endpoint = window.AppConfig.ENDPOINTS.ADMIN.BLOCK_USER.replace('{userId}', currentUser.id);
                await window.ApiClient.post(endpoint, { reason: blockReason });
            } else if (currentUser.isBlocked && status !== 'blocked') {
                // 차단 해제
                const endpoint = window.AppConfig.ENDPOINTS.ADMIN.UNBLOCK_USER.replace('{userId}', currentUser.id);
                await window.ApiClient.post(endpoint, {});
            }

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('사용자 정보가 업데이트되었습니다', 'success');
            }

            // 모달 닫기
            const modal = window.bootstrap.Modal.getInstance(document.getElementById('userDetailModal'));
            if (modal) modal.hide();

            // 목록 새로고침
            loadDashboardData();

        } catch (err) {
            console.error('Save user changes error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('사용자 정보 업데이트 실패', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    };

    window.handleUserAction = async function(userId, action) {
        if (action === 'block') {
            if (!confirm('이 사용자를 차단하시겠습니까?')) return;
        } else if (action === 'unblock') {
            if (!confirm('이 사용자의 차단을 해제하시겠습니까?')) return;
        }

        try {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            if (action === 'block') {
                const endpoint = window.AppConfig.ENDPOINTS.ADMIN.BLOCK_USER.replace('{userId}', userId);
                await window.ApiClient.post(endpoint, { reason: '관리자에 의한 차단' });
            } else if (action === 'unblock') {
                const endpoint = window.AppConfig.ENDPOINTS.ADMIN.UNBLOCK_USER.replace('{userId}', userId);
                await window.ApiClient.post(endpoint, {});
            }

            if (window.UI && window.UI.showToast) {
                window.UI.showToast(action === 'block' ? '사용자가 차단되었습니다' : '사용자 차단이 해제되었습니다', 'success');
            }

            loadUsersList(currentUserPage);

        } catch (err) {
            console.error('User action error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('작업 실패', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    };

    window.handleSubscriptionAction = async function(subscriptionId, action) {
        if (!confirm(`구독을 ${action === 'approve' ? '승인' : '거절'}하시겠습니까?`)) return;

        try {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            if (action === 'approve') {
                const endpoint = window.AppConfig.ENDPOINTS.ADMIN.APPROVE_SUBSCRIPTION.replace('{subscriptionId}', subscriptionId);
                await window.ApiClient.post(endpoint, {});
            } else if (action === 'reject') {
                const endpoint = window.AppConfig.ENDPOINTS.ADMIN.REJECT_SUBSCRIPTION.replace('{subscriptionId}', subscriptionId);
                await window.ApiClient.post(endpoint, { reason: '관리자에 의한 거절' });
            }

            if (window.UI && window.UI.showToast) {
                window.UI.showToast(action === 'approve' ? '구독이 승인되었습니다' : '구독이 거절되었습니다', 'success');
            }

            loadDashboardData();

        } catch (err) {
            console.error('Subscription action error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('작업 실패', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    };

    // 헬퍼 함수
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ko-KR');
    }

})();