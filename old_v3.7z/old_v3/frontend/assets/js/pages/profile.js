// profile.js - 프로필 페이지 로직
// 브라우저 호환 버전

(function() {
    'use strict';

    // DOM 준비 완료 시 실행
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        console.log('Profile page initialized');
        
        // 인증 확인
        if (!window.AuthManager || !window.AuthManager.checkAuthentication()) {
            return;
        }

        // 프로필 데이터 로드
        loadProfileData();
        
        // 이벤트 리스너 설정
        setupEventHandlers();
    }

    async function loadProfileData() {
        try {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            // 사용자 정보 조회
            const user = window.AuthManager.getUserInfo();
            displayUserInfo(user);

            // 추가 프로필 정보 조회 (API에서)
            if (window.ApiClient) {
                const profileData = await window.ApiClient.get(
                    window.AppConfig.ENDPOINTS.USER.PROFILE
                );

                // 폼에 데이터 채우기
                if (profileData) {
                    document.getElementById('firstName').value = profileData.firstName || '';
                    document.getElementById('lastName').value = profileData.lastName || '';
                    document.getElementById('email').value = profileData.email || '';
                    document.getElementById('phone').value = profileData.phoneNumber || '';

                    if (profileData.createdAt) {
                        document.getElementById('joinDate').textContent = formatDate(profileData.createdAt);
                    }
                    if (profileData.lastLogin) {
                        document.getElementById('lastLogin').textContent = formatDateTime(profileData.lastLogin);
                    }
                }
            }

            // 구독 정보 조회
            if (window.ApiClient) {
                const subscription = await window.ApiClient.get(
                    window.AppConfig.ENDPOINTS.SUBSCRIPTION.GET_MY
                );

                if (subscription) {
                    displaySubscriptionInfo(subscription);
                }
            }

        } catch (err) {
            console.error('Profile load error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('프로필 정보를 로드할 수 없습니다', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    function displayUserInfo(user) {
        if (!user) return;

        // 이름 표시
        const fullName = `${user.firstName} ${user.lastName}`;
        document.getElementById('userName').textContent = fullName;
        document.getElementById('userEmail').textContent = user.email;

        // 아바타 이니셜
        const initial = (user.firstName.charAt(0) + user.lastName.charAt(0)).toUpperCase();
        document.getElementById('avatarInitial').textContent = initial;

        // 계정 상태
        let statusClass = 'bg-success';
        let statusText = '활성';

        if (user.isBlocked) {
            statusClass = 'bg-danger';
            statusText = '차단됨';
        } else if (!user.isActive) {
            statusClass = 'bg-warning';
            statusText = '비활성';
        }

        const statusBadge = document.getElementById('accountStatus');
        if (statusBadge) {
            statusBadge.className = `badge ${statusClass}`;
            statusBadge.textContent = statusText;
        }
    }

    function displaySubscriptionInfo(subscription) {
        const tierName = subscription.tierName || subscription.tier_name || '-';
        const status = subscription.status || '-';
        const limit = subscription.apiLimit || subscription.api_call_limit || '-';
        const currentUsage = subscription.currentUsage || subscription.current_usage || 0;

        document.getElementById('subscriptionTier').textContent = tierName;
        
        const statusBadge = document.getElementById('subscriptionStatus');
        if (statusBadge) {
            const statusClass = status === 'active' ? 'bg-success' : 'bg-warning';
            statusBadge.className = `badge ${statusClass}`;
            statusBadge.textContent = status === 'active' ? '활성' : '대기 중';
        }

        document.getElementById('apiLimit').textContent = `${formatNumber(limit)} 회`;
        document.getElementById('currentUsage').textContent = `${formatNumber(currentUsage)} 회 / ${formatNumber(limit)} 회`;
    }

    function setupEventHandlers() {
        // 프로필 폼 제출
        const profileForm = document.getElementById('profileForm');
        if (profileForm) {
            profileForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                await updateProfile();
            });
        }

        // 비밀번호 폼 제출
        const passwordForm = document.getElementById('passwordForm');
        if (passwordForm) {
            passwordForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                await updatePassword();
            });
        }

        // 로그아웃 버튼
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (window.AuthManager) {
                    window.AuthManager.logout();
                }
            });
        }

        // 계정 삭제 버튼
        const deleteAccountBtn = document.getElementById('deleteAccountBtn');
        if (deleteAccountBtn) {
            deleteAccountBtn.addEventListener('click', () => {
                handleDeleteAccount();
            });
        }

        // 실시간 검증
        if (window.Validation && window.Validation.setupFieldValidation) {
            const firstNameField = document.getElementById('firstName');
            const lastNameField = document.getElementById('lastName');
            const phoneField = document.getElementById('phone');

            if (firstNameField) {
                window.Validation.setupFieldValidation(firstNameField, 'name');
            }
            if (lastNameField) {
                window.Validation.setupFieldValidation(lastNameField, 'name');
            }
            if (phoneField) {
                window.Validation.setupFieldValidation(phoneField, 'phone');
            }
        }
    }

    async function updateProfile() {
        try {
            // 폼 검증
            if (!window.Validation || !window.Validation.validateForm) {
                return;
            }

            const isValid = window.Validation.validateForm('profileForm', {
                firstName: 'name',
                lastName: 'name',
                phone: 'phone'
            });

            if (!isValid) return;

            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            const formData = {
                firstName: document.getElementById('firstName').value.trim(),
                lastName: document.getElementById('lastName').value.trim(),
                phoneNumber: document.getElementById('phone').value.trim()
            };

            const response = await window.ApiClient.put(
                window.AppConfig.ENDPOINTS.USER.UPDATE_PROFILE,
                formData
            );

            // 사용자 정보 업데이트
            window.AuthManager.setUserInfo(response);
            displayUserInfo(response);

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('프로필이 업데이트되었습니다', 'success');
            }

        } catch (err) {
            console.error('Profile update error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('프로필 업데이트 실패', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    async function updatePassword() {
        try {
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            // 비밀번호 검증
            if (!window.Validation || !window.Validation.ValidationRules) {
                return;
            }

            const passwordError = window.Validation.ValidationRules.password(newPassword);
            if (passwordError) {
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast(passwordError, 'error');
                }
                return;
            }

            if (newPassword !== confirmPassword) {
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('새 비밀번호가 일치하지 않습니다', 'error');
                }
                return;
            }

            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            await window.ApiClient.post(
                window.AppConfig.ENDPOINTS.USER.CHANGE_PASSWORD,
                {
                    oldPassword: currentPassword,
                    newPassword: newPassword
                }
            );

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('비밀번호가 변경되었습니다', 'success');
            }

            // 폼 초기화
            document.getElementById('passwordForm').reset();

        } catch (err) {
            console.error('Password update error:', err);
            if (window.UI && window.UI.showToast) {
                const message = err.message || '비밀번호 변경 실패';
                window.UI.showToast(message, 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    function handleDeleteAccount() {
        if (!window.UI || !window.UI.showConfirm) {
            return;
        }

        const confirmText = '정말로 계정을 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.\n\n계정 삭제 후 30일 동안 복구 가능합니다.';

        window.UI.showConfirm(
            confirmText,
            () => {
                deleteAccount();
            },
            () => {
                console.log('Account deletion cancelled');
            }
        );
    }

    async function deleteAccount() {
        try {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            // 백엔드에서 DELETE 엔드포인트 구현 필요
            // await window.ApiClient.delete('/api/users/profile');

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('계정이 삭제되었습니다', 'success');
            }

            // 토큰 삭제 후 로그인 페이지로 이동
            setTimeout(() => {
                window.AuthManager.clearTokens();
                window.location.href = '/pages/auth/login.html';
            }, 1000);

        } catch (err) {
            console.error('Account deletion error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('계정 삭제 실패', 'error');
            }
        } finally {
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

    // 헬퍼 함수들 (전역 스코프에 정의된 함수 사용)
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ko-KR', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });
    }

    function formatDateTime(dateString) {
        const date = new Date(dateString);
        return date.toLocaleString('ko-KR', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }

    function formatNumber(num) {
        return new Intl.NumberFormat('ko-KR').format(num);
    }

})();