// api-keys.js - API 키 관리 페이지 로직

(function() {
    'use strict';

    // 상태 관리
    const state = {
        apiKeys: [],
        currentKeyId: null
    };

    // DOM 준비 완료 시 실행
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    /**
     * 초기화 함수
     */
    function init() {
        console.log('API Keys page initialized');

        // 인증 확인
        if (!window.AuthManager || !window.AuthManager.checkAuthentication()) {
            return;
        }

        // 사용자 정보 표시
        displayUserInfo();

        // 이벤트 리스너 설정
        setupEventHandlers();

        // API 키 데이터 로드
        loadApiKeys();
    }

    /**
     * 사용자 정보 표시
     */
    function displayUserInfo() {
        const user = window.AuthManager.getUserInfo();

        if (user) {
            document.getElementById('userName').textContent = `${user.firstName} ${user.lastName}`;
        }
    }

    /**
     * 이벤트 리스너 설정
     */
    function setupEventHandlers() {
        // API 키 생성 버튼
        const createApiKeyBtn = document.getElementById('createApiKeyBtn');
        if (createApiKeyBtn) {
            createApiKeyBtn.addEventListener('click', () => {
                openModal('createApiKeyModal');
            });
        }

        // API 키 생성 제출 버튼
        const createApiKeySubmitBtn = document.getElementById('createApiKeySubmitBtn');
        if (createApiKeySubmitBtn) {
            createApiKeySubmitBtn.addEventListener('click', () => {
                submitCreateApiKey();
            });
        }

        // 클립보드 복사 버튼
        const copyKeyBtn = document.getElementById('copyKeyBtn');
        if (copyKeyBtn) {
            copyKeyBtn.addEventListener('click', () => {
                copyToClipboard();
            });
        }

        // 로그아웃 버튼
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                if (window.AuthManager) {
                    window.AuthManager.logout();
                }
            });
        }

        // 모달 닫기 버튼
        document.querySelectorAll('[data-modal-close]').forEach(btn => {
            btn.addEventListener('click', () => {
                const modalId = btn.getAttribute('data-modal-close');
                closeModal(modalId);
            });
        });

        document.querySelectorAll('.close-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const modalId = btn.getAttribute('data-modal');
                closeModal(modalId);
            });
        });
    }

    /**
     * API 키 로드
     */
    async function loadApiKeys() {
        try {
            if (!window.ApiClient) {
                console.error('ApiClient not loaded');
                return;
            }

            showLoader(true);

            const response = await window.ApiClient.get(
                window.AppConfig.ENDPOINTS.API_KEYS.LIST
            );

            state.apiKeys = response;
            displayApiKeys(response);

        } catch (err) {
            console.error('API keys load error:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('API 키를 로드할 수 없습니다', 'error');
            }
            displayEmptyState();
        } finally {
            showLoader(false);
        }
    }

    /**
     * API 키 표시
     */
    function displayApiKeys(keys) {
        const container = document.getElementById('apiKeysContainer');
        if (!container) return;

        if (!keys || keys.length === 0) {
            displayEmptyState();
            return;
        }

        const keysHTML = keys.map(key => {
            const createdAt = new Date(key.createdAt).toLocaleDateString('ko-KR', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            });

            const lastUsed = key.lastUsed 
                ? new Date(key.lastUsed).toLocaleDateString('ko-KR', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit'
                })
                : '사용 없음';

            const status = key.isActive 
                ? '<span class="badge bg-success">활성</span>' 
                : '<span class="badge bg-danger">비활성</span>';

            const displayKey = key.apiKey 
                ? key.apiKey.substring(0, 10) + '...' 
                : 'N/A';

            return `
                <tr>
                    <td>
                        <strong>${key.keyName || 'Unnamed'}</strong>
                    </td>
                    <td>
                        <code style="font-size: 12px; background-color: #f8f9fa; padding: 3px 5px; border-radius: 3px;">
                            ${displayKey}
                        </code>
                    </td>
                    <td>${status}</td>
                    <td>${createdAt}</td>
                    <td>${lastUsed}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-sm btn-info" onclick="window.apiKeysModule.viewKey('${key.id}', '${key.apiKey}')" title="상세 보기">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="window.apiKeysModule.revokeKey('${key.id}', '${key.keyName}')" title="삭제">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        container.innerHTML = keysHTML;
    }

    /**
     * 빈 상태 표시
     */
    function displayEmptyState() {
        const container = document.getElementById('apiKeysContainer');
        if (!container) return;

        container.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-4">
                    <div class="empty-state">
                        <i class="fas fa-key"></i>
                        <p>생성된 API 키가 없습니다</p>
                        <p class="text-muted">상단의 "새 API 키 생성" 버튼을 클릭하여 첫 번째 키를 생성하세요.</p>
                    </div>
                </td>
            </tr>
        `;
    }

    /**
     * API 키 생성 제출
     */
    async function submitCreateApiKey() {
        try {
            const keyName = document.getElementById('apiKeyName').value.trim();
            const expiry = document.getElementById('apiKeyExpiry').value;

            if (!keyName) {
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('키 이름을 입력하세요', 'error');
                }
                return;
            }

            showLoader(true);

            const response = await window.ApiClient.post(
                window.AppConfig.ENDPOINTS.API_KEYS.CREATE,
                { 
                    keyName,
                    expiry: expiry !== 'never' ? parseInt(expiry) : null
                }
            );

            // 폼 초기화
            document.getElementById('createApiKeyForm').reset();

            // 모달 닫기
            closeModal('createApiKeyModal');

            // 상세 정보 표시
            if (response.apiKey) {
                showKeyDetail(response.apiKey);
            }

            // 목록 새로고침
            loadApiKeys();

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('API 키가 생성되었습니다', 'success');
            }

        } catch (err) {
            console.error('Create API key error:', err);
            if (window.UI && window.UI.showToast) {
                const message = err.message || 'API 키 생성 실패';
                window.UI.showToast(message, 'error');
            }
        } finally {
            showLoader(false);
        }
    }

    /**
     * 키 상세 정보 표시
     */
    function showKeyDetail(apiKey) {
        document.getElementById('apiKeyValue').textContent = apiKey;
        state.currentKeyId = apiKey;
        openModal('apiKeyDetailModal');
    }

    /**
     * API 키 삭제
     */
    async function revokeKey(keyId, keyName) {
        try {
            if (!confirm(`"${keyName}" API 키를 삭제하시겠습니까?`)) {
                return;
            }

            showLoader(true);

            const endpoint = window.AppConfig.ENDPOINTS.API_KEYS.REVOKE.replace('{keyId}', keyId);
            await window.ApiClient.delete(endpoint);

            // 목록 새로고침
            loadApiKeys();

            if (window.UI && window.UI.showToast) {
                window.UI.showToast('API 키가 삭제되었습니다', 'success');
            }

        } catch (err) {
            console.error('Revoke API key error:', err);
            if (window.UI && window.UI.showToast) {
                const message = err.message || 'API 키 삭제 실패';
                window.UI.showToast(message, 'error');
            }
        } finally {
            showLoader(false);
        }
    }

    /**
     * 클립보드에 복사
     */
    function copyToClipboard() {
        const keyValue = document.getElementById('apiKeyValue').textContent;
        
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(keyValue).then(() => {
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('클립보드에 복사되었습니다', 'success');
                }
            }).catch(err => {
                console.error('Failed to copy:', err);
                fallbackCopy(keyValue);
            });
        } else {
            fallbackCopy(keyValue);
        }
    }

    /**
     * 대체 복사 방식 (보안 컨텍스트 없을 때)
     */
    function fallbackCopy(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        
        try {
            document.execCommand('copy');
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('클립보드에 복사되었습니다', 'success');
            }
        } catch (err) {
            console.error('Fallback copy failed:', err);
            if (window.UI && window.UI.showToast) {
                window.UI.showToast('복사 실패', 'error');
            }
        }
        
        document.body.removeChild(textArea);
    }

    /**
     * 모달 열기
     */
    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            modal.style.display = 'block';
        }
    }

    /**
     * 모달 닫기
     */
    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            modal.style.display = 'none';
        }
    }

    /**
     * 로더 표시/숨김
     */
    function showLoader(show = true) {
        const loader = document.getElementById('loader');
        if (loader) {
            loader.style.display = show ? 'block' : 'none';
        }
    }

    // 전역 네임스페이스에 노출
    window.apiKeysModule = {
        viewKey: (keyId, apiKey) => {
            showKeyDetail(apiKey);
        },
        revokeKey: revokeKey
    };

})();