// login.js - 로그인 페이지 로직
// HTML의 마지막 <script> 태그로 로드되어야 함

(function() {
    'use strict';

    // DOM 준비 완료 시 실행
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        console.log('Login page initialized');
        
        // 이미 로그인한 경우 대시보드로 이동
        if (window.AuthManager && window.AuthManager.isAuthenticated()) {
            window.location.href = '/pages/dashboard.html';
            return;
        }

        // 폼 이벤트 리스너 설정
        setupFormHandlers();
    }

    function setupFormHandlers() {
        const loginForm = document.getElementById('loginForm');
        if (!loginForm) {
            console.error('Login form not found');
            return;
        }

        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            await handleLogin();
        });

        // 실시간 검증 설정
        const emailField = document.getElementById('email');
        const passwordField = document.getElementById('password');

        if (window.Validation && window.Validation.setupFieldValidation) {
            if (emailField) {
                window.Validation.setupFieldValidation(emailField, 'email');
            }
        }
    }

    async function handleLogin() {
        try {
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;

            // 검증
            if (!window.Validation || !window.Validation.validateForm) {
                console.error('Validation module not loaded');
                return;
            }

            const isValid = window.Validation.validateForm('loginForm', {
                email: 'email',
                password: 'required'
            });

            if (!isValid) {
                return;
            }

            // 로딩 표시
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(true);
            }

            // API 호출
            if (!window.ApiClient) {
                console.error('ApiClient not loaded');
                throw new Error('API 클라이언트를 로드할 수 없습니다');
            }

            const response = await window.ApiClient.post(
                window.AppConfig.ENDPOINTS.AUTH.LOGIN,
                { email, password }
            );

            // 토큰 저장
            if (window.AuthManager && window.AuthManager.setTokens) {
                window.AuthManager.setTokens(
                    response.accessToken,
                    response.refreshToken
                );

                // 사용자 정보 저장
                if (response.user) {
                    window.AuthManager.setUserInfo(response.user);
                }

                // 토큰 자동 갱신 설정
                if (window.AuthManager.setupTokenRefresh) {
                    window.AuthManager.setupTokenRefresh();
                }

                // 성공 메시지
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('로그인 성공', 'success');
                }

                // 대시보드로 리다이렉트
                setTimeout(() => {
                    window.location.href = '/pages/dashboard.html';
                }, 500);
            }
        } catch (err) {
            console.error('Login error:', err);
            if (window.UI && window.UI.showToast) {
                const message = err.message || '로그인 실패';
                window.UI.showToast(message, 'error');
            }
        } finally {
            // 로딩 숨김
            if (window.UI && window.UI.showLoader) {
                window.UI.showLoader(false);
            }
        }
    }

})();