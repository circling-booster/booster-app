// auth-manager.js - 브라우저 호환 버전
// IIFE 패턴으로 캡슐화

(function() {
    'use strict';

    const AuthManager = {
        /**
         * 토큰 저장소
         */
        getTokens() {
            return {
                accessToken: localStorage.getItem(AppConfig.TOKEN_CONFIG.ACCESS_TOKEN_KEY),
                refreshToken: localStorage.getItem(AppConfig.TOKEN_CONFIG.REFRESH_TOKEN_KEY)
            };
        },

        setTokens(accessToken, refreshToken) {
            localStorage.setItem(AppConfig.TOKEN_CONFIG.ACCESS_TOKEN_KEY, accessToken);
            localStorage.setItem(AppConfig.TOKEN_CONFIG.REFRESH_TOKEN_KEY, refreshToken);
        },

        clearTokens() {
            localStorage.removeItem(AppConfig.TOKEN_CONFIG.ACCESS_TOKEN_KEY);
            localStorage.removeItem(AppConfig.TOKEN_CONFIG.REFRESH_TOKEN_KEY);
            localStorage.removeItem(AppConfig.TOKEN_CONFIG.USER_KEY);
        },

        /**
         * 사용자 정보 저장/조회
         */
        setUserInfo(user) {
            localStorage.setItem(AppConfig.TOKEN_CONFIG.USER_KEY, JSON.stringify(user));
        },

        getUserInfo() {
            const data = localStorage.getItem(AppConfig.TOKEN_CONFIG.USER_KEY);
            return data ? JSON.parse(data) : null;
        },

        /**
         * 로그인 상태 확인
         */
        isAuthenticated() {
            const tokens = this.getTokens();
            return !!(tokens.accessToken && tokens.refreshToken);
        },

        /**
         * 관리자 권한 확인
         */
        isAdmin() {
            const user = this.getUserInfo();
            return user && user.isAdmin;
        },

        /**
         * 토큰 갱신
         */
        async refreshAccessToken() {
            try {
                const tokens = this.getTokens();
                
                if (!tokens.refreshToken) {
                    return false;
                }

                const response = await fetch(
                    `${AppConfig.API_CONFIG.API_BASE_URL}${AppConfig.ENDPOINTS.AUTH.REFRESH_TOKEN}`,
                    {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ refreshToken: tokens.refreshToken })
                    }
                );

                if (!response.ok) {
                    this.clearTokens();
                    return false;
                }

                const result = await response.json();
                localStorage.setItem(AppConfig.TOKEN_CONFIG.ACCESS_TOKEN_KEY, result.data.accessToken);
                return true;
            } catch (err) {
                console.error('Token refresh failed:', err);
                this.clearTokens();
                return false;
            }
        },

        /**
         * 로그아웃
         */
        logout() {
            this.clearTokens();
            window.location.href = '/pages/auth/login.html';
        },

        /**
         * 토큰 자동 갱신 설정
         */
        setupTokenRefresh() {
            // 10분마다 토큰 갱신 확인
            setInterval(() => {
                if (this.isAuthenticated()) {
                    this.refreshAccessToken();
                }
            }, 10 * 60 * 1000);
        },

        /**
         * 페이지 로드 시 권한 확인
         */
        checkAuthentication(requiredRole = null) {
            if (!this.isAuthenticated()) {
                window.location.href = '/pages/auth/login.html';
                return false;
            }

            if (requiredRole === 'admin' && !this.isAdmin()) {
                if (window.UI && window.UI.showToast) {
                    window.UI.showToast('관리자 권한이 필요합니다', 'error');
                }
                window.location.href = '/';
                return false;
            }

            return true;
        }
    };

    // 전역 네임스페이스에 노출
    window.AuthManager = AuthManager;

})();