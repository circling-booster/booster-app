// assets/js/chart-config.js

/**
 * 월별 API 호출량 차트
 */
function createMonthlyUsageChart(canvasId, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.months || [],
            datasets: [{
                label: 'API 호출',
                data: data.calls || [],
                borderColor: '#007bff',
                backgroundColor: 'rgba(0, 123, 255, 0.1)',
                tension: 0.3,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

/**
 * 상태 코드 분포 차트
 */
function createStatusCodeChart(canvasId, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['200 OK', '400 Bad Request', '401 Unauthorized', '500 Error'],
            datasets: [{
                data: data,
                backgroundColor: [
                    '#28a745', // 200
                    '#ffc107', // 400
                    '#fd7e14', // 401
                    '#dc3545'  // 500
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

/**
 * 구독 현황 차트
 */
function createSubscriptionChart(canvasId, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Basic', 'Premium', 'Enterprise'],
            datasets: [{
                label: '구독 인원',
                data: [data.basic, data.premium, data.enterprise],
                backgroundColor: [
                    '#007bff',
                    '#28a745',
                    '#ffc107'
                ]
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

/**
 * API Key별 사용량 차트
 */
function createApiKeyUsageChart(canvasId, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    const labels = data.map(d => d.keyName);
    const callCounts = data.map(d => d.calls);

    return new Chart(ctx, {
        type: 'horizontalBar',
        data: {
            labels,
            datasets: [{
                label: 'API 호출 수',
                data: callCounts,
                backgroundColor: '#007bff'
            }]
        },
        options: {
            responsive: true,
            indexAxis: 'y'
        }
    });
}

export {
    createMonthlyUsageChart,
    createStatusCodeChart,
    createSubscriptionChart,
    createApiKeyUsageChart
};
