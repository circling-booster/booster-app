// api-client.js - 브라우저 호환 버전
// IIFE 패턴으로 캡슐화

(function() {
    'use strict';

    class ApiClient {
        constructor() {
            this.baseURL = AppConfig.API_CONFIG.API_BASE_URL;
            this.timeout = 10000;
        }

        /**
         * HTTP 요청 실행
         */
        async request(method, endpoint, data = null, options = {}) {
            try {
                let url = `${this.baseURL}${endpoint}`;
                const headers = this.buildHeaders(options.headers || {});

                const config = {
                    method,
                    headers,
                    timeout: this.timeout
                };

                // 요청 본문 추가
                if (data && (method === 'POST' || method === 'PUT')) {
                    config.body = JSON.stringify(data);
                }

                // 쿼리 문자열 추가
                if (data && method === 'GET') {
                    const queryString = new URLSearchParams(data).toString();
                    url = url + (queryString ? `?${queryString}` : '');
                }

                const response = await fetch(url, config);

                // 401 에러: 토큰 갱신 후 재시도
                if (response.status === 401) {
                    const refreshed = await window.AuthManager.refreshAccessToken();
                    if (refreshed) {
                        return this.request(method, endpoint, data, options);
                    }
                    // 토큰 갱신 실패 → 로그인 페이지로 리다이렉트
                    window.location.href = '/pages/auth/login.html';
                    return null;
                }

                const result = await response.json();

                if (!response.ok) {
                    throw {
                        status: response.status,
                        message: result.message || 'API 요청 실패',
                        errorCode: result.errorCode,
                        details: result.details
                    };
                }

                return result.data;
            } catch (err) {
                this.handleError(err, options.silent);
                throw err;
            }
        }

        /**
         * 요청 헤더 생성
         */
        buildHeaders(customHeaders = {}) {
            const headers = {
                'Content-Type': 'application/json',
                ...customHeaders
            };

            // Authorization 헤더 추가
            const tokens = window.AuthManager.getTokens();
            if (tokens.accessToken) {
                headers.Authorization = `Bearer ${tokens.accessToken}`;
            }

            return headers;
        }

        /**
         * GET 요청
         */
        async get(endpoint, params = null) {
            return this.request('GET', endpoint, params);
        }

        /**
         * POST 요청
         */
        async post(endpoint, data) {
            return this.request('POST', endpoint, data);
        }

        /**
         * PUT 요청
         */
        async put(endpoint, data) {
            return this.request('PUT', endpoint, data);
        }

        /**
         * DELETE 요청
         */
        async delete(endpoint) {
            return this.request('DELETE', endpoint);
        }

        /**
         * 에러 처리
         */
        handleError(err, silent = false) {
            if (silent) return;

            let message = err.message || 'Unknown error';

            if (err.status === 0) {
                message = 'Network error - 서버에 연결할 수 없습니다';
            } else if (err.status === 403) {
                message = '접근 권한이 없습니다';
            } else if (err.status === 404) {
                message = '요청한 리소스를 찾을 수 없습니다';
            } else if (err.status === 429) {
                message = 'API 호출 제한을 초과했습니다';
            }

            if (window.UI && window.UI.showToast) {
                window.UI.showToast(message, 'error');
            }
            console.error('API Error:', err);
        }
    }

    // 단일 인스턴스 생성
    const apiClient = new ApiClient();

    // 전역 네임스페이스에 노출
    window.ApiClient = apiClient;

})();