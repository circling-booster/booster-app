// validation.js - 브라우저 호환 버전
// IIFE 패턴으로 캡슐화

(function() {
    'use strict';

    const ValidationRules = {
        // 이메일 검증
        email: (value) => {
            const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return regex.test(value) ? null : '유효한 이메일 주소를 입력하세요';
        },

        // 비밀번호 검증 (최소 8자, 대문자, 소문자, 숫자, 특수문자)
        password: (value) => {
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            if (!regex.test(value)) {
                return '비밀번호는 최소 8자이며 대문자, 소문자, 숫자, 특수문자를 포함해야 합니다';
            }
            return null;
        },

        // 휴대폰 번호 검증
        phone: (value) => {
            const regex = /^01[0-9]-?\d{3,4}-?\d{4}$/;
            return regex.test(value) ? null : '유효한 휴대폰 번호를 입력하세요 (01X-XXXX-XXXX)';
        },

        // 이름 검증
        name: (value) => {
            if (!value || value.length < 2 || value.length > 50) {
                return '이름은 2자 이상 50자 이하여야 합니다';
            }
            return null;
        },

        // URL 검증
        url: (value) => {
            try {
                new URL(value);
                return null;
            } catch (e) {
                return '유효한 URL을 입력하세요';
            }
        },

        // 필수 검증
        required: (value) => {
            return !value || value.trim() === '' ? '필수 입력 사항입니다' : null;
        }
    };

    /**
     * 입력 필드 검증
     */
    function validateField(fieldElement, rule) {
        const value = fieldElement.value.trim();
        const error = ValidationRules[rule](value);
        
        if (error) {
            fieldElement.classList.add('is-invalid');
            fieldElement.classList.remove('is-valid');
            
            // 에러 메시지 표시
            let feedback = fieldElement.nextElementSibling;
            if (!feedback || !feedback.classList.contains('invalid-feedback')) {
                feedback = document.createElement('div');
                feedback.className = 'invalid-feedback';
                fieldElement.parentNode.insertBefore(feedback, fieldElement.nextSibling);
            }
            feedback.textContent = error;
            
            return false;
        } else {
            fieldElement.classList.remove('is-invalid');
            fieldElement.classList.add('is-valid');
            return true;
        }
    }

    /**
     * 폼 검증
     */
    function validateForm(formId, rules) {
        const form = document.getElementById(formId);
        let isValid = true;

        for (const [fieldName, rule] of Object.entries(rules)) {
            const field = form.querySelector(`[name="${fieldName}"]`);
            if (field && !validateField(field, rule)) {
                isValid = false;
            }
        }

        return isValid;
    }

    /**
     * 실시간 필드 검증 설정
     */
    function setupFieldValidation(fieldElement, rule) {
        fieldElement.addEventListener('blur', () => {
            validateField(fieldElement, rule);
        });

        fieldElement.addEventListener('input', () => {
            if (fieldElement.classList.contains('is-invalid')) {
                validateField(fieldElement, rule);
            }
        });
    }

    // 전역 네임스페이스에 노출
    window.Validation = {
        ValidationRules: ValidationRules,
        validateField: validateField,
        validateForm: validateForm,
        setupFieldValidation: setupFieldValidation
    };

})();