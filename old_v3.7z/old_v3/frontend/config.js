// config.js - 브라우저 호환 버전
// 전역 네임스페이스에 설정 객체 노출

(function() {
    'use strict';

    // 환경 설정
    const CONFIG = {
        development: {
            API_BASE_URL: 'http://localhost:3000/api',
            WEBSOCKET_URL: 'ws://localhost:3000'
        },
        production: {
            API_BASE_URL: 'https://booster-app.azurewebsites.net/api',
            WEBSOCKET_URL: 'wss://booster-app.azurewebsites.net'
        }
    };

    // 현재 환경 설정 (프로덕션으로 기본값 설정)
    const ENV = window.location.hostname === 'localhost' ? 'development' : 'production';
    const API_CONFIG = CONFIG[ENV];

    // 토큰 관련 상수
    const TOKEN_CONFIG = {
        ACCESS_TOKEN_KEY: 'access_token',
        REFRESH_TOKEN_KEY: 'refresh_token',
        USER_KEY: 'user_info',
        TOKEN_EXPIRY_BUFFER: 5 * 60 * 1000 // 5분 전에 갱신
    };

    // API 엔드포인트
    const ENDPOINTS = {
        // 인증
        AUTH: {
            SIGNUP: '/auth/signup',
            LOGIN: '/auth/login',
            REFRESH_TOKEN: '/auth/refresh-token'
        },
        
        // 사용자
        USER: {
            PROFILE: '/users/profile',
            UPDATE_PROFILE: '/users/profile',
            CHANGE_PASSWORD: '/users/change-password'
        },
        
        // 구독
        SUBSCRIPTION: {
            REQUEST: '/subscriptions/request',
            GET_MY: '/subscriptions/my-subscription',
            GET_TIERS: '/subscriptions/tiers'
        },
        
        // API 키
        API_KEYS: {
            CREATE: '/api-keys',
            LIST: '/api-keys',
            REVOKE: '/api-keys/{keyId}'
        },
        
        // 대시보드
        DASHBOARD: {
            STATS: '/dashboard/stats',
            LOGS: '/dashboard/logs'
        },
        
        // 관리자
        ADMIN: {
            USERS_LIST: '/admin/users',
            SUBSCRIPTIONS_PENDING: '/admin/subscriptions/pending',
            APPROVE_SUBSCRIPTION: '/admin/subscriptions/{subscriptionId}/approve',
            REJECT_SUBSCRIPTION: '/admin/subscriptions/{subscriptionId}/reject',
            BLOCK_USER: '/admin/users/{userId}/block',
            UNBLOCK_USER: '/admin/users/{userId}/unblock',
            STATS: '/admin/stats'
        },
        
        // Webhook
        WEBHOOKS: {
            CREATE: '/webhooks',
            LIST: '/webhooks'
        }
    };

    // 구독 Tier 설정
    const SUBSCRIPTION_TIERS = {
        BASIC: {
            id: 1,
            name: 'Basic',
            limit: 1000,
            price: 0,
            features: ['API 호출 월 1,000회', '기본 지원', '단일 API 키']
        },
        PREMIUM: {
            id: 2,
            name: 'Premium',
            limit: 5000,
            price: 99.99,
            features: ['API 호출 월 5,000회', '우선 지원', '다중 API 키', 'Webhook 지원']
        },
        ENTERPRISE: {
            id: 3,
            name: 'Enterprise',
            limit: 999999,
            price: 'Custom',
            features: ['무제한 API 호출', '24/7 지원', '커스텀 통합', 'SLA 보장']
        }
    };

    // 오류 메시지 정의
    const ERROR_MESSAGES = {
        INVALID_CREDENTIALS: '이메일 또는 비밀번호가 일치하지 않습니다',
        USER_NOT_FOUND: '사용자를 찾을 수 없습니다',
        USER_BLOCKED: '차단된 계정입니다',
        SUBSCRIPTION_INACTIVE: '활성화된 구독이 없습니다',
        API_LIMIT_EXCEEDED: 'API 호출 제한을 초과했습니다',
        INVALID_API_KEY: '유효하지 않은 API 키입니다',
        INVALID_TOKEN: '유효하지 않은 토큰입니다',
        NETWORK_ERROR: '네트워크 오류가 발생했습니다',
        UNAUTHORIZED: '권한이 없습니다',
        FORBIDDEN: '접근이 거부되었습니다'
    };

    // 전역 네임스페이스에 노출
    window.AppConfig = {
        API_CONFIG: API_CONFIG,
        TOKEN_CONFIG: TOKEN_CONFIG,
        ENDPOINTS: ENDPOINTS,
        SUBSCRIPTION_TIERS: SUBSCRIPTION_TIERS,
        ERROR_MESSAGES: ERROR_MESSAGES
    };

})();