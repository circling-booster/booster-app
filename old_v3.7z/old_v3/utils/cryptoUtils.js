const crypto = require('crypto');
const bcrypt = require('bcryptjs');

// 비밀번호 해싱
async function hashPassword(password) {
    return await bcrypt.hash(password, 10);
}

// 비밀번호 검증
async function verifyPassword(password, hash) {
    return await bcrypt.compare(password, hash);
}

// API Secret 암호화 (SHA256)
function encryptApiSecret(secret) {
    return crypto
        .createHash('sha256')
        .update(secret)
        .digest('hex');
}

// API Key 생성
function generateApiKey() {
    return 'sk_' + crypto.randomBytes(24).toString('hex');
}

// API Secret 생성
function generateApiSecret() {
    return crypto.randomBytes(32).toString('hex');
}

// UUID 생성
function generateUUID() {
    return crypto.randomUUID();
}

// 토큰 생성
function generateToken(length = 32) {
    return crypto.randomBytes(length).toString('hex');
}

// HMAC 서명 생성 (Webhook용)
function createHmacSignature(payload, secret) {
    return crypto
        .createHmac('sha256', secret)
        .update(JSON.stringify(payload))
        .digest('hex');
}

module.exports = {
    hashPassword,
    verifyPassword,
    encryptApiSecret,
    generateApiKey,
    generateApiSecret,
    generateUUID,
    generateToken,
    createHmacSignature
};
