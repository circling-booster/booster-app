const jwt = require('jsonwebtoken');

// Access Token 생성
function generateAccessToken(userId, isAdmin = false) {
    return jwt.sign(
        {
            userId,
            isAdmin,
            type: 'access'
        },
        process.env.JWT_SECRET,
        {
            expiresIn: process.env.JWT_EXPIRE || '7d'
        }
    );
}

// Refresh Token 생성
function generateRefreshToken(userId) {
    return jwt.sign(
        {
            userId,
            type: 'refresh'
        },
        process.env.JWT_REFRESH_SECRET,
        {
            expiresIn: process.env.JWT_REFRESH_EXPIRE || '30d'
        }
    );
}

// 토큰 검증
function verifyToken(token, isRefresh = false) {
    try {
        const secret = isRefresh ? process.env.JWT_REFRESH_SECRET : process.env.JWT_SECRET;
        return jwt.verify(token, secret);
    } catch (err) {
        return null;
    }
}

// Authorization 헤더에서 토큰 추출
function extractTokenFromHeader(authHeader) {
    if (!authHeader) return null;
    
    const parts = authHeader.split(' ');
    if (parts.length !== 2 || parts !== 'Bearer') return null;
    
    return parts;
}

module.exports = {
    generateAccessToken,
    generateRefreshToken,
    verifyToken,
    extractTokenFromHeader
};
