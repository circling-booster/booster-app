// 이메일 검증
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// 비밀번호 검증 (최소 8자, 대문자, 소문자, 숫자, 특수문자)
function validatePassword(password) {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return regex.test(password);
}

// 휴대폰 번호 검증
function validatePhoneNumber(phone) {
    const phoneRegex = /^01[0-9]-?\d{3,4}-?\d{4}$/;
    return phoneRegex.test(phone);
}

// 이름 검증
function validateName(name) {
    return name && name.length >= 2 && name.length <= 50;
}

// SQL Injection 방지
function sanitizeInput(input) {
    if (typeof input !== 'string') return input;
    
    return input
        .replace(/['";\\]/g, '')
        .trim();
}

// 입력값 검증
function validateSignupInput(data) {
    const errors = {};
    
    if (!validateName(data.firstName)) {
        errors.firstName = '이름은 2자 이상 50자 이하여야 합니다';
    }
    
    if (!validateName(data.lastName)) {
        errors.lastName = '성은 2자 이상 50자 이하여야 합니다';
    }
    
    if (!validateEmail(data.email)) {
        errors.email = '유효한 이메일 주소를 입력하세요';
    }
    
    if (!validatePhoneNumber(data.phoneNumber)) {
        errors.phoneNumber = '유효한 휴대폰 번호를 입력하세요 (01X-XXXX-XXXX)';
    }
    
    if (!validatePassword(data.password)) {
        errors.password = '비밀번호는 최소 8자이며 대문자, 소문자, 숫자, 특수문자를 포함해야 합니다';
    }
    
    return {
        isValid: Object.keys(errors).length === 0,
        errors
    };
}

module.exports = {
    validateEmail,
    validatePassword,
    validatePhoneNumber,
    validateName,
    sanitizeInput,
    validateSignupInput
};
