const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

const SALT_ROUNDS = 10;

// 비밀번호 해싱
const hashPassword = async (password) => {
    return bcrypt.hash(password, SALT_ROUNDS);
};

// 비밀번호 검증
const verifyPassword = async (password, hash) => {
    return bcrypt.compare(password, hash);
};

// API 시크릿 해싱 (SHA256)
const hashApiSecret = (secret) => {
    return crypto.createHash('sha256').update(secret).digest('hex');
};

// API 키 생성 (sk_ 접두사 + 24바이트 난수)
const generateApiKey = () => {
    const randomBytes = crypto.randomBytes(24).toString('hex');
    return `sk_${randomBytes}`;
};

// API 시크릿 생성 (32바이트 난수)
const generateApiSecret = () => {
    return crypto.randomBytes(32).toString('hex');
};

// UUID 생성
const generateUUID = () => {
    return uuidv4();
};

// 임의 토큰 생성
const generateToken = (length = 32) => {
    return crypto.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length);
};

// Webhook 서명 생성 (HMAC-SHA256)
const generateWebhookSignature = (payload, secret) => {
    return crypto
        .createHmac('sha256', secret)
        .update(JSON.stringify(payload))
        .digest('hex');
};

module.exports = {
    hashPassword,
    verifyPassword,
    hashApiSecret,
    generateApiKey,
    generateApiSecret,
    generateUUID,
    generateToken,
    generateWebhookSignature
};