// 이메일 검증
const validateEmail = (email) => {
    const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
    return emailRegex.test(email);
};

// 비밀번호 검증 (최소 8자, 대문자, 소문자, 숫자, 특수문자 필수)
const validatePassword = (password) => {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/;
    return passwordRegex.test(password);
};

// 한국 휴대폰 번호 검증 (01X-XXXX-XXXX)
const validatePhoneNumber = (phone) => {
    const phoneRegex = /^01[0-9]-\\d{3,4}-\\d{4}$/;
    return phoneRegex.test(phone);
};

// 이름 검증 (2~50자)
const validateName = (name) => {
    return name && name.length >= 2 && name.length <= 50;
};

// SQL Injection 방지 - 입력값 정제
const sanitizeInput = (input) => {
    if (typeof input !== 'string') {
        return input;
    }
    
    // 특수문자 제거, 영문, 숫자, 한글, 공백만 허용
    return input.replace(/[^a-zA-Z0-9\\s\\-_.@가-힣]/g, '');
};

// 회원가입 종합 검증
const validateSignupInput = (data) => {
    const errors = {};

    // 이메일 검증
    if (!data.email || !validateEmail(data.email)) {
        errors.email = 'Invalid email format';
    }

    // 이름 검증
    if (!data.firstName || !validateName(data.firstName)) {
        errors.firstName = 'First name must be between 2 and 50 characters';
    }

    if (!data.lastName || !validateName(data.lastName)) {
        errors.lastName = 'Last name must be between 2 and 50 characters';
    }

    // 휴대폰 검증
    if (!data.phoneNumber || !validatePhoneNumber(data.phoneNumber)) {
        errors.phoneNumber = 'Invalid phone number format (use 01X-XXXX-XXXX)';
    }

    // 비밀번호 검증
    if (!data.password || !validatePassword(data.password)) {
        errors.password = 'Password must be at least 8 characters and contain uppercase, lowercase, number, and special character';
    }

    // 비밀번호 확인
    if (data.password !== data.passwordConfirm) {
        errors.passwordConfirm = 'Passwords do not match';
    }

    return {
        isValid: Object.keys(errors).length === 0,
        errors
    };
};

module.exports = {
    validateEmail,
    validatePassword,
    validatePhoneNumber,
    validateName,
    sanitizeInput,
    validateSignupInput
};