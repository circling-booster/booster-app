const errorResponse = (res, message, errorCode = 'ERROR', statusCode = 400, details = null) => {
    return res.status(statusCode).json({
        success: false,
        message,
        errorCode,
        details,
        timestamp: new Date().toISOString()
    });
};

module.exports = errorResponse;