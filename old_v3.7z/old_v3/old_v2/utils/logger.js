const fs = require('fs');
const path = require('path');

const LOG_DIR = process.env.LOG_DIR || './logs';
const LOG_LEVEL = process.env.LOG_LEVEL || 'info';

// logs 디렉토리 생성
if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
}

const getLogFilePath = () => {
    const date = new Date().toISOString().split('T')[0];
    return path.join(LOG_DIR, `error-${date}.log`);
};

const formatLog = (level, message, error = null) => {
    const timestamp = new Date().toISOString();
    let logMessage = `[${timestamp}] [${level}] ${message}`;
    
    if (error && error.stack) {
        logMessage += `\\n${error.stack}`;
    }
    
    return logMessage;
};

const log = (level, message, error = null) => {
    const logMessage = formatLog(level, message, error);
    
    // 콘솔 출력
    console.log(logMessage);
    
    // 에러 레벨은 파일에도 저장
    if (level === 'ERROR' || level === 'WARN') {
        const filePath = getLogFilePath();
        fs.appendFileSync(filePath, logMessage + '\\n', { encoding: 'utf-8' });
    }
};

module.exports = {
    info: (message) => log('INFO', message),
    warn: (message) => log('WARN', message),
    error: (message, error = null) => log('ERROR', message, error),
    debug: (message) => {
        if (process.env.NODE_ENV === 'development') {
            log('DEBUG', message);
        }
    }
};