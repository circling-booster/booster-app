const jwt = require('jsonwebtoken');
const logger = require('./logger');

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET;
const JWT_EXPIRE = process.env.JWT_EXPIRE || '7d';
const JWT_REFRESH_EXPIRE = process.env.JWT_REFRESH_EXPIRE || '30d';

// Access Token 생성
const createAccessToken = (userId, isAdmin = false) => {
    try {
        const token = jwt.sign(
            {
                userId,
                isAdmin,
                type: 'access'
            },
            JWT_SECRET,
            { expiresIn: JWT_EXPIRE }
        );
        return token;
    } catch (error) {
        logger.error(`Failed to create access token: ${error.message}`, error);
        throw error;
    }
};

// Refresh Token 생성
const createRefreshToken = (userId, isAdmin = false) => {
    try {
        const token = jwt.sign(
            {
                userId,
                isAdmin,
                type: 'refresh'
            },
            JWT_REFRESH_SECRET,
            { expiresIn: JWT_REFRESH_EXPIRE }
        );
        return token;
    } catch (error) {
        logger.error(`Failed to create refresh token: ${error.message}`, error);
        throw error;
    }
};

// 토큰 검증
const verifyAccessToken = (token) => {
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        return decoded;
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            throw {
                statusCode: 401,
                message: 'Token expired',
                errorCode: 'TOKEN_EXPIRED'
            };
        }
        throw {
            statusCode: 401,
            message: 'Invalid token',
            errorCode: 'INVALID_TOKEN'
        };
    }
};

// Refresh Token 검증
const verifyRefreshToken = (token) => {
    try {
        const decoded = jwt.verify(token, JWT_REFRESH_SECRET);
        return decoded;
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            throw {
                statusCode: 401,
                message: 'Refresh token expired',
                errorCode: 'TOKEN_EXPIRED'
            };
        }
        throw {
            statusCode: 401,
            message: 'Invalid refresh token',
            errorCode: 'INVALID_TOKEN'
        };
    }
};

// Bearer 토큰 추출
const extractBearerToken = (authHeader) => {
    if (!authHeader) {
        return null;
    }

    const parts = authHeader.split(' ');
    if (parts.length !== 2 || parts[0] !== 'Bearer') {
        return null;
    }

    return parts[1];
};

module.exports = {
    createAccessToken,
    createRefreshToken,
    verifyAccessToken,
    verifyRefreshToken,
    extractBearerToken
};