// Configuration
const CONFIG = {
    // API Configuration
    API: {
        BASE_URL: window.location.origin === 'http://localhost:3000' 
            ? 'http://localhost:3000/api'
            : '/api'
    },

    // Endpoints
    ENDPOINTS: {
        // Auth
        AUTH_SIGNUP: '/auth/signup',
        AUTH_LOGIN: '/auth/login',
        AUTH_REFRESH: '/auth/refresh-token',

        // API Keys
        API_KEYS_CREATE: '/api-keys',
        API_KEYS_LIST: '/api-keys',
        API_KEYS_REVOKE: (id) => `/api-keys/${id}`,

        // Subscriptions
        SUBSCRIPTION_REQUEST: '/subscriptions/request',
        SUBSCRIPTION_GET: '/subscriptions',
        SUBSCRIPTION_TIERS: '/subscriptions/tiers',

        // User
        USER_PROFILE: '/users/profile',

        // Dashboard
        DASHBOARD_STATS: '/dashboard/stats',
        DASHBOARD_LOGS: '/dashboard/logs',

        // Admin
        ADMIN_USERS: '/admin/users',
        ADMIN_PENDING_SUBS: '/admin/subscriptions/pending',
        ADMIN_APPROVE_SUB: (id) => `/admin/subscriptions/${id}/approve`,
        ADMIN_REJECT_SUB: (id) => `/admin/subscriptions/${id}/reject`,
        ADMIN_BLOCK_USER: (userId) => `/admin/users/${userId}/block`,
        ADMIN_UNBLOCK_USER: (userId) => `/admin/users/${userId}/unblock`,
        ADMIN_STATS: '/admin/stats'
    },

    // Local Storage Keys
    STORAGE_KEYS: {
        ACCESS_TOKEN: 'booster_access_token',
        REFRESH_TOKEN: 'booster_refresh_token',
        USER_INFO: 'booster_user_info'
    },

    // UI Configuration
    UI: {
        ITEMS_PER_PAGE: 10,
        TOAST_DURATION: 3000,
        CHART_COLORS: ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6']
    },

    // Subscription Tiers
    TIERS: {
        BASIC: { id: 1, name: 'Basic', limit: 1000, price: 29.99 },
        PREMIUM: { id: 2, name: 'Premium', limit: 5000, price: 99.99 },
        ENTERPRISE: { id: 3, name: 'Enterprise', limit: 'Unlimited', price: 'Custom' }
    }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}