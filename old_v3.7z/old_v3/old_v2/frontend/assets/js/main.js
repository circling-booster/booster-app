// Main Application Logic
let currentPage = 'login';

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    if (authManager.isLoggedIn()) {
        showPage('dashboard');
        loadDashboard();
    } else {
        showPage('login');
    }

    setupEventListeners();
});

// Page Navigation
function showPage(page) {
    // Hide all sections
    document.querySelectorAll('.page-section').forEach(el => el.style.display = 'none');

    // Show selected page
    const pageId = `${page}-section`;
    const pageElement = document.getElementById(pageId);
    if (pageElement) {
        pageElement.style.display = 'block';
    }

    // Update admin visibility
    if (!authManager.isLoggedIn() || !authManager.isAdmin()) {
        document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'none');
    } else {
        document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'block');
    }

    currentPage = page;
}

// Setup Event Listeners
function setupEventListeners() {
    // Navigation
    document.getElementById('nav-dashboard')?.addEventListener('click', (e) => {
        e.preventDefault();
        showPage('dashboard');
        loadDashboard();
    });

    document.getElementById('nav-api-keys')?.addEventListener('click', (e) => {
        e.preventDefault();
        showPage('api-keys');
        loadApiKeys();
    });

    document.getElementById('nav-subscription')?.addEventListener('click', (e) => {
        e.preventDefault();
        showPage('subscription');
        loadSubscription();
    });

    document.getElementById('nav-admin')?.addEventListener('click', (e) => {
        e.preventDefault();
        showPage('admin');
        loadAdminDashboard();
    });

    document.getElementById('btn-logout')?.addEventListener('click', () => {
        authManager.logout();
        showPage('login');
        showToast('Logged out successfully');
    });

    // Auth Forms
    document.getElementById('login-form')?.addEventListener('submit', handleLogin);
    document.getElementById('signup-form')?.addEventListener('submit', handleSignup);

    document.getElementById('toggle-signup')?.addEventListener('click', (e) => {
        e.preventDefault();
        showPage('signup');
    });

    document.getElementById('toggle-login')?.addEventListener('click', (e) => {
        e.preventDefault();
        showPage('login');
    });

    // API Keys
    document.getElementById('btn-create-key')?.addEventListener('click', () => {
        document.getElementById('create-key-form').style.display = 'block';
    });

    document.getElementById('btn-cancel-key')?.addEventListener('click', () => {
        document.getElementById('create-key-form').style.display = 'none';
    });

    document.getElementById('key-form')?.addEventListener('submit', handleCreateApiKey);
}

// Authentication Handlers
async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    const response = await apiClient.post(CONFIG.ENDPOINTS.AUTH_LOGIN, { email, password });

    if (response.success) {
        const { user, accessToken, refreshToken } = response.data;
        authManager.setTokens(accessToken, refreshToken, user);
        showToast('Login successful');
        showPage('dashboard');
        loadDashboard();
    } else {
        showToast(response.message, 'error');
    }
}

async function handleSignup(e) {
    e.preventDefault();

    const data = {
        firstName: document.getElementById('signup-firstName').value,
        lastName: document.getElementById('signup-lastName').value,
        email: document.getElementById('signup-email').value,
        phoneNumber: document.getElementById('signup-phone').value,
        password: document.getElementById('signup-password').value,
        passwordConfirm: document.getElementById('signup-passwordConfirm').value
    };

    const response = await apiClient.post(CONFIG.ENDPOINTS.AUTH_SIGNUP, data);

    if (response.success) {
        showToast('Account created successfully. Please login.');
        showPage('login');
    } else {
        const errorMsg = response.details 
            ? Object.values(response.details).join(', ')
            : response.message;
        showToast(errorMsg, 'error');
    }
}

// Dashboard
async function loadDashboard() {
    const response = await apiClient.get(CONFIG.ENDPOINTS.DASHBOARD_STATS);
    
    if (response.success) {
        document.getElementById('stat-total-calls').textContent = response.data.totalCalls || 0;
        
        // Load recent logs
        const logsResponse = await apiClient.get(CONFIG.ENDPOINTS.DASHBOARD_LOGS);
        if (logsResponse.success) {
            populateLogsTable(logsResponse.data.logs);
        }
    }
}

function populateLogsTable(logs) {
    const tbody = document.getElementById('logs-table-body');
    tbody.innerHTML = '';

    logs.forEach(log => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${log.endpoint}</td>
            <td>${log.method}</td>
            <td><span class="status-${log.status_code}">${log.status_code}</span></td>
            <td>${log.response_time_ms || 'N/A'}ms</td>
            <td>${new Date(log.created_at).toLocaleString('ko-KR')}</td>
        `;
        tbody.appendChild(row);
    });
}

// API Keys
async function loadApiKeys() {
    const response = await apiClient.get(CONFIG.ENDPOINTS.API_KEYS_LIST);
    
    if (response.success) {
        const container = document.getElementById('keys-list');
        container.innerHTML = '';
        document.getElementById('stat-api-keys').textContent = response.data.keys.length;

        response.data.keys.forEach(key => {
            const card = document.createElement('div');
            card.className = 'card api-key-card';
            card.innerHTML = `
                <h4>${key.keyName}</h4>
                <p><strong>Key:</strong> ${key.apiKey.substring(0, 20)}...</p>
                <p><strong>Status:</strong> ${key.isActive ? 'Active' : 'Inactive'}</p>
                <p><strong>Created:</strong> ${new Date(key.createdAt).toLocaleDateString('ko-KR')}</p>
                <button onclick="revokeApiKey('${key.id}')" class="btn-danger">Revoke</button>
            `;
            container.appendChild(card);
        });
    }
}

async function handleCreateApiKey(e) {
    e.preventDefault();

    const keyName = document.getElementById('key-name').value;
    const response = await apiClient.post(CONFIG.ENDPOINTS.API_KEYS_CREATE, { keyName });

    if (response.success) {
        showToast('API key created successfully');
        document.getElementById('key-form').reset();
        document.getElementById('create-key-form').style.display = 'none';
        loadApiKeys();
    } else {
        showToast(response.message, 'error');
    }
}

async function revokeApiKey(keyId) {
    if (confirm('Are you sure you want to revoke this API key?')) {
        const response = await apiClient.delete(CONFIG.ENDPOINTS.API_KEYS_REVOKE(keyId));
        
        if (response.success) {
            showToast('API key revoked');
            loadApiKeys();
        } else {
            showToast(response.message, 'error');
        }
    }
}

// Subscription
async function loadSubscription() {
    // Load tiers
    const tiersResponse = await apiClient.get(CONFIG.ENDPOINTS.SUBSCRIPTION_TIERS);
    if (tiersResponse.success) {
        const container = document.getElementById('subscription-tiers');
        container.innerHTML = '';

        tiersResponse.data.tiers.forEach(tier => {
            const card = document.createElement('div');
            card.className = 'card tier-card';
            card.innerHTML = `
                <h3>${tier.name}</h3>
                <p><strong>Limit:</strong> ${tier.limit.toLocaleString()} calls/month</p>
                <p><strong>Price:</strong> $${tier.price}</p>
                <p>${tier.description}</p>
                <button onclick="requestSubscription(${tier.id})" class="btn-primary">Select Plan</button>
            `;
            container.appendChild(card);
        });
    }

    // Load current subscription
    const subResponse = await apiClient.get(CONFIG.ENDPOINTS.SUBSCRIPTION_GET);
    if (subResponse.success && subResponse.data) {
        const container = document.getElementById('current-subscription');
        container.innerHTML = `
            <p><strong>Plan:</strong> ${subResponse.data.tier_name}</p>
            <p><strong>Status:</strong> ${subResponse.data.status}</p>
            <p><strong>Created:</strong> ${new Date(subResponse.data.created_at).toLocaleDateString('ko-KR')}</p>
        `;
        document.getElementById('stat-subscription').textContent = subResponse.data.status;
    }
}

async function requestSubscription(tierId) {
    const response = await apiClient.post(CONFIG.ENDPOINTS.SUBSCRIPTION_REQUEST, { tierId });
    
    if (response.success) {
        showToast('Subscription requested successfully. Awaiting approval.');
        loadSubscription();
    } else {
        showToast(response.message, 'error');
    }
}

// Admin Dashboard
async function loadAdminDashboard() {
    // Load stats
    const statsResponse = await apiClient.get(CONFIG.ENDPOINTS.ADMIN_STATS);
    if (statsResponse.success) {
        document.getElementById('admin-total-users').textContent = statsResponse.data.totalUsers;
        document.getElementById('admin-active-subs').textContent = statsResponse.data.activeSubscriptions;
        document.getElementById('admin-pending-subs').textContent = statsResponse.data.pendingSubscriptions;
        document.getElementById('admin-blocked-users').textContent = statsResponse.data.blockedUsers;
    }

    // Load pending subscriptions
    const pendingResponse = await apiClient.get(CONFIG.ENDPOINTS.ADMIN_PENDING_SUBS);
    if (pendingResponse.success) {
        const tbody = document.getElementById('pending-subs-body');
        tbody.innerHTML = '';

        pendingResponse.data.subscriptions.forEach(sub => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${sub.userName}</td>
                <td>${sub.email}</td>
                <td>${sub.tierName}</td>
                <td>${new Date(sub.createdAt).toLocaleDateString('ko-KR')}</td>
                <td>
                    <button onclick="approveSub('${sub.id}')" class="btn-success">Approve</button>
                    <button onclick="rejectSub('${sub.id}')" class="btn-danger">Reject</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    // Load users
    const usersResponse = await apiClient.get(CONFIG.ENDPOINTS.ADMIN_USERS);
    if (usersResponse.success) {
        const tbody = document.getElementById('users-body');
        tbody.innerHTML = '';

        usersResponse.data.users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.email}</td>
                <td>${user.firstName} ${user.lastName}</td>
                <td>${user.isBlocked ? 'Blocked' : 'Active'}</td>
                <td>
                    ${user.isBlocked 
                        ? `<button onclick="unblockUser('${user.id}')" class="btn-success">Unblock</button>`
                        : `<button onclick="blockUser('${user.id}')" class="btn-danger">Block</button>`
                    }
                </td>
            `;
            tbody.appendChild(row);
        });
    }
}

async function approveSub(subId) {
    const response = await apiClient.post(CONFIG.ENDPOINTS.ADMIN_APPROVE_SUB(subId), {});
    if (response.success) {
        showToast('Subscription approved');
        loadAdminDashboard();
    } else {
        showToast(response.message, 'error');
    }
}

async function rejectSub(subId) {
    const reason = prompt('Enter rejection reason:');
    if (reason) {
        const response = await apiClient.post(CONFIG.ENDPOINTS.ADMIN_REJECT_SUB(subId), { reason });
        if (response.success) {
            showToast('Subscription rejected');
            loadAdminDashboard();
        } else {
            showToast(response.message, 'error');
        }
    }
}

async function blockUser(userId) {
    const reason = prompt('Enter block reason:');
    if (reason) {
        const response = await apiClient.post(CONFIG.ENDPOINTS.ADMIN_BLOCK_USER(userId), { reason });
        if (response.success) {
            showToast('User blocked');
            loadAdminDashboard();
        } else {
            showToast(response.message, 'error');
        }
    }
}

async function unblockUser(userId) {
    const response = await apiClient.post(CONFIG.ENDPOINTS.ADMIN_UNBLOCK_USER(userId), {});
    if (response.success) {
        showToast('User unblocked');
        loadAdminDashboard();
    } else {
        showToast(response.message, 'error');
    }
}

// Utility Functions
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast show ${type}`;
    
    setTimeout(() => {
        toast.className = 'toast';
    }, CONFIG.UI.TOAST_DURATION);
}