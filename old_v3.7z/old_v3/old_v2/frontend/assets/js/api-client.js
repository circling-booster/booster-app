// API Client
class ApiClient {
    constructor(baseURL) {
        this.baseURL = baseURL;
        this._retry = false;
    }

    async _request(method, endpoint, data = null, headers = {}) {
        const url = `${this.baseURL}${endpoint}`;
        
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json',
                ...headers
            }
        };

        // Add authorization token if available
        const token = localStorage.getItem(CONFIG.STORAGE_KEYS.ACCESS_TOKEN);
        if (token) {
            options.headers.Authorization = `Bearer ${token}`;
        }

        // Add request body if provided
        if (data) {
            options.body = JSON.stringify(data);
        }

        try {
            const response = await fetch(url, options);
            let responseData;

            try {
                responseData = await response.json();
            } catch (e) {
                responseData = { success: false, message: response.statusText };
            }

            // Handle 401 - Try to refresh token
            if (response.status === 401 && !this._retry) {
                this._retry = true;
                const refreshed = await this._refreshToken();
                if (refreshed) {
                    this._retry = false;
                    return this._request(method, endpoint, data, headers);
                }
            }

            this._retry = false;
            return responseData;
        } catch (error) {
            console.error('API request failed:', error);
            return {
                success: false,
                message: error.message,
                errorCode: 'NETWORK_ERROR'
            };
        }
    }

    async _refreshToken() {
        const refreshToken = localStorage.getItem(CONFIG.STORAGE_KEYS.REFRESH_TOKEN);
        if (!refreshToken) {
            return false;
        }

        const response = await this._request('POST', CONFIG.ENDPOINTS.AUTH_REFRESH, { refreshToken }, {}, true);
        
        if (response.success && response.data?.accessToken) {
            localStorage.setItem(CONFIG.STORAGE_KEYS.ACCESS_TOKEN, response.data.accessToken);
            return true;
        }

        return false;
    }

    // HTTP Methods
    get(endpoint) {
        return this._request('GET', endpoint);
    }

    post(endpoint, data, headers = {}) {
        return this._request('POST', endpoint, data, headers);
    }

    put(endpoint, data, headers = {}) {
        return this._request('PUT', endpoint, data, headers);
    }

    delete(endpoint) {
        return this._request('DELETE', endpoint);
    }
}

// Create global API client instance
const apiClient = new ApiClient(CONFIG.API.BASE_URL);