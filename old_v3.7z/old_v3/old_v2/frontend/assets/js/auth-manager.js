// Authentication Manager
class AuthManager {
    constructor() {
        this.accessToken = this._getFromStorage(CONFIG.STORAGE_KEYS.ACCESS_TOKEN);
        this.refreshToken = this._getFromStorage(CONFIG.STORAGE_KEYS.REFRESH_TOKEN);
        this.userInfo = this._getFromStorage(CONFIG.STORAGE_KEYS.USER_INFO);
    }

    _getFromStorage(key) {
        const value = localStorage.getItem(key);
        if (!value) return null;

        try {
            // Try to parse as JSON, fallback to string
            return value === 'undefined' ? null : JSON.parse(value);
        } catch (e) {
            return value;
        }
    }

    setTokens(accessToken, refreshToken, userInfo) {
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
        this.userInfo = userInfo;

        localStorage.setItem(CONFIG.STORAGE_KEYS.ACCESS_TOKEN, accessToken);
        localStorage.setItem(CONFIG.STORAGE_KEYS.REFRESH_TOKEN, refreshToken);
        localStorage.setItem(CONFIG.STORAGE_KEYS.USER_INFO, JSON.stringify(userInfo));
    }

    isLoggedIn() {
        return !!this.accessToken;
    }

    isAdmin() {
        return this.userInfo?.isAdmin === true;
    }

    logout() {
        this.accessToken = null;
        this.refreshToken = null;
        this.userInfo = null;

        localStorage.removeItem(CONFIG.STORAGE_KEYS.ACCESS_TOKEN);
        localStorage.removeItem(CONFIG.STORAGE_KEYS.REFRESH_TOKEN);
        localStorage.removeItem(CONFIG.STORAGE_KEYS.USER_INFO);
    }

    getUserInfo() {
        return this.userInfo;
    }
}

const authManager = new AuthManager();