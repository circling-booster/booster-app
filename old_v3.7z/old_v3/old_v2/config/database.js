const mssql = require('mssql');
const logger = require('../utils/logger');

const config = {
    server: process.env.DB_SERVER,
    database: process.env.DB_DATABASE,
    authentication: {
        type: 'default',
        options: {
            userName: process.env.DB_USER,
            password: process.env.DB_PASSWORD
        }
    },
    options: {
        encrypt: process.env.DB_ENCRYPTION === 'true',
        trustServerCertificate: process.env.DB_TRUST_CERTIFICATE === 'true',
        connectTimeout: 30000,
        requestTimeout: 30000,
        connectionTimeout: 30000
    },
    pool: {
        min: 2,
        max: 10,
        idleTimeoutMillis: 30000
    }
};

let pool = null;

const initializeDatabase = async () => {
    try {
        pool = new mssql.ConnectionPool(config);
        await pool.connect();
        logger.info('Database pool connected');

        pool.on('error', (err) => {
            logger.error(`Database pool error: ${err.message}`, err);
        });

        return pool;
    } catch (error) {
        logger.error(`Database initialization failed: ${error.message}`, error);
        throw error;
    }
};

const executeQuery = async (query, params = {}) => {
    if (!pool) {
        throw new Error('Database pool not initialized');
    }

    try {
        const request = pool.request();
        
        // 파라미터 바인딩 (SQL Injection 방지)
        Object.keys(params).forEach(key => {
            request.input(key, params[key]);
        });

        const result = await request.query(query);
        return result.recordset || [];
    } catch (error) {
        logger.error(`Query execution failed: ${error.message}`, error);
        throw {
            statusCode: 400,
            message: 'Database query error',
            errorCode: 'DATABASE_ERROR',
            details: error.message
        };
    }
};

const executeNonQuery = async (query, params = {}) => {
    if (!pool) {
        throw new Error('Database pool not initialized');
    }

    try {
        const request = pool.request();
        
        // 파라미터 바인딩 (SQL Injection 방지)
        Object.keys(params).forEach(key => {
            request.input(key, params[key]);
        });

        const result = await request.query(query);
        return {
            rowsAffected: result.rowsAffected[0] || 0,
            recordset: result.recordset || []
        };
    } catch (error) {
        logger.error(`Non-query execution failed: ${error.message}`, error);
        throw {
            statusCode: 400,
            message: 'Database operation error',
            errorCode: 'DATABASE_ERROR',
            details: error.message
        };
    }
};

const closeDatabase = async () => {
    if (pool) {
        try {
            await pool.close();
            logger.info('Database pool closed');
        } catch (error) {
            logger.error(`Error closing database pool: ${error.message}`, error);
        }
    }
};

module.exports = {
    initializeDatabase,
    executeQuery,
    executeNonQuery,
    closeDatabase,
    getPool: () => pool
};