const SUBSCRIPTION_STATUS = {
    PENDING: 'pending',
    ACTIVE: 'active',
    EXPIRED: 'expired',
    CANCELLED: 'cancelled'
};

const API_KEY_STATUS = {
    ACTIVE: 'active',
    INACTIVE: 'inactive',
    EXPIRED: 'expired'
};

const RATE_LIMIT_TYPES = {
    HOURLY: 'hourly',
    MONTHLY: 'monthly',
    IP_BASED: 'ip_based'
};

const SUBSCRIPTION_TIERS = {
    BASIC: {
        id: 1,
        name: 'Basic',
        limit: 1000
    },
    PREMIUM: {
        id: 2,
        name: 'Premium',
        limit: 5000
    },
    ENTERPRISE: {
        id: 3,
        name: 'Enterprise',
        limit: 2147483647
    }
};

const WEBHOOK_EVENTS = {
    SUBSCRIPTION_ACTIVATED: 'subscription_activated',
    SUBSCRIPTION_EXPIRED: 'subscription_expired',
    SUBSCRIPTION_CANCELLED: 'subscription_cancelled',
    API_LIMIT_REACHED: 'api_limit_reached',
    API_LIMIT_WARNING: 'api_limit_warning',
    USER_BLOCKED: 'user_blocked'
};

const ERROR_CODES = {
    INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
    USER_NOT_FOUND: 'USER_NOT_FOUND',
    USER_BLOCKED: 'USER_BLOCKED',
    USER_INACTIVE: 'USER_INACTIVE',
    EMAIL_ALREADY_EXISTS: 'EMAIL_ALREADY_EXISTS',
    INVALID_TOKEN: 'INVALID_TOKEN',
    TOKEN_EXPIRED: 'TOKEN_EXPIRED',
    UNAUTHORIZED: 'UNAUTHORIZED',
    FORBIDDEN: 'FORBIDDEN',
    API_KEY_INVALID: 'API_KEY_INVALID',
    API_KEY_EXPIRED: 'API_KEY_EXPIRED',
    RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
    DATABASE_ERROR: 'DATABASE_ERROR',
    VALIDATION_ERROR: 'VALIDATION_ERROR'
};

module.exports = {
    SUBSCRIPTION_STATUS,
    API_KEY_STATUS,
    RATE_LIMIT_TYPES,
    SUBSCRIPTION_TIERS,
    WEBHOOK_EVENTS,
    ERROR_CODES
};