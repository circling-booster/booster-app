const User = require('../models/User');
const { hashPassword, verifyPassword, generateUUID } = require('../utils/cryptoUtils');
const { createAccessToken, createRefreshToken } = require('../utils/tokenUtils');
const logger = require('../utils/logger');

const authService = {
    // 회원가입
    registerUser: async (userData) => {
        try {
            // 이메일 중복 확인
            const existingUser = await User.findByEmail(userData.email);
            if (existingUser) {
                throw {
                    statusCode: 400,
                    message: 'Email already exists',
                    errorCode: 'EMAIL_ALREADY_EXISTS'
                };
            }

            // 비밀번호 해싱
            const passwordHash = await hashPassword(userData.password);

            // 새 사용자 생성
            const newUser = await User.create({
                id: generateUUID(),
                firstName: userData.firstName,
                lastName: userData.lastName,
                email: userData.email,
                phoneNumber: userData.phoneNumber,
                passwordHash,
                isActive: true,
                isAdmin: false
            });

            logger.info(`New user registered: ${newUser.email}`);

            return {
                id: newUser.id,
                email: newUser.email,
                firstName: newUser.first_name,
                lastName: newUser.last_name
            };
        } catch (error) {
            logger.error(`Registration error: ${error.message}`, error);
            throw error;
        }
    },

    // 로그인
    loginUser: async (email, password) => {
        try {
            const user = await User.findByEmail(email);

            if (!user) {
                throw {
                    statusCode: 401,
                    message: 'Invalid credentials',
                    errorCode: 'INVALID_CREDENTIALS'
                };
            }

            // 비밀번호 검증
            const isPasswordValid = await verifyPassword(password, user.password_hash);
            if (!isPasswordValid) {
                throw {
                    statusCode: 401,
                    message: 'Invalid credentials',
                    errorCode: 'INVALID_CREDENTIALS'
                };
            }

            // 차단 확인
            if (user.is_blocked) {
                throw {
                    statusCode: 403,
                    message: 'User account is blocked',
                    errorCode: 'USER_BLOCKED',
                    details: user.blocked_reason
                };
            }

            // 활성화 상태 확인
            if (!user.is_active) {
                throw {
                    statusCode: 403,
                    message: 'User account is not active',
                    errorCode: 'USER_INACTIVE'
                };
            }

            // 마지막 로그인 시간 업데이트
            await User.updateLastLogin(user.id);

            // 토큰 생성
            const accessToken = createAccessToken(user.id, user.is_admin === 1);
            const refreshToken = createRefreshToken(user.id, user.is_admin === 1);

            logger.info(`User logged in: ${user.email}`);

            return {
                user: {
                    id: user.id,
                    email: user.email,
                    firstName: user.first_name,
                    lastName: user.last_name,
                    isAdmin: user.is_admin === 1
                },
                accessToken,
                refreshToken
            };
        } catch (error) {
            logger.error(`Login error: ${error.message}`, error);
            throw error;
        }
    },

    // 토큰 갱신
    refreshAccessToken: async (refreshToken) => {
        try {
            const { verifyRefreshToken, createAccessToken } = require('../utils/tokenUtils');
            
            const decoded = verifyRefreshToken(refreshToken);
            const user = await User.findById(decoded.userId);

            if (!user || !user.is_active) {
                throw {
                    statusCode: 401,
                    message: 'Invalid refresh token',
                    errorCode: 'INVALID_TOKEN'
                };
            }

            const newAccessToken = createAccessToken(user.id, user.is_admin === 1);
            return { accessToken: newAccessToken };
        } catch (error) {
            logger.error(`Token refresh error: ${error.message}`, error);
            throw error;
        }
    }
};

module.exports = authService;