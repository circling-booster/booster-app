const User = require('../models/User');
const Subscription = require('../models/Subscription');
const ApiLog = require('../models/ApiLog');
const { executeQuery } = require('../config/database');
const logger = require('../utils/logger');

const adminService = {
    // 모든 사용자 조회
    getAllUsers: async (page = 1, limit = 10) => {
        try {
            const users = await User.findAll(page, limit);
            const total = await User.count();

            return {
                users: users.map(u => ({
                    id: u.id,
                    email: u.email,
                    firstName: u.first_name,
                    lastName: u.last_name,
                    isActive: u.is_active === 1,
                    isBlocked: u.is_blocked === 1,
                    blockedReason: u.blocked_reason,
                    createdAt: u.created_at
                })),
                total,
                page,
                limit
            };
        } catch (error) {
            logger.error(`Get all users error: ${error.message}`, error);
            throw error;
        }
    },

    // 대기 중인 구독 조회
    getPendingSubscriptions: async (page = 1, limit = 10) => {
        try {
            const subscriptions = await Subscription.findPending(page, limit);
            return subscriptions.map(s => ({
                id: s.id,
                userId: s.user_id,
                email: s.email,
                userName: `${s.first_name} ${s.last_name}`,
                tierName: s.tier_name,
                status: s.status,
                createdAt: s.created_at
            }));
        } catch (error) {
            logger.error(`Get pending subscriptions error: ${error.message}`, error);
            throw error;
        }
    },

    // 구독 승인
    approveSubscription: async (subscriptionId, approvedBy) => {
        try {
            await Subscription.approve(subscriptionId, approvedBy);
            logger.info(`Subscription approved: ${subscriptionId}`);
        } catch (error) {
            logger.error(`Approve subscription error: ${error.message}`, error);
            throw error;
        }
    },

    // 구독 거절
    rejectSubscription: async (subscriptionId, reason) => {
        try {
            await Subscription.reject(subscriptionId, reason);
            logger.info(`Subscription rejected: ${subscriptionId}`);
        } catch (error) {
            logger.error(`Reject subscription error: ${error.message}`, error);
            throw error;
        }
    },

    // 사용자 차단
    blockUser: async (userId, reason) => {
        try {
            await User.blockUser(userId, reason);
            logger.info(`User blocked: ${userId}`);
        } catch (error) {
            logger.error(`Block user error: ${error.message}`, error);
            throw error;
        }
    },

    // 사용자 차단 해제
    unblockUser: async (userId) => {
        try {
            await User.unblockUser(userId);
            logger.info(`User unblocked: ${userId}`);
        } catch (error) {
            logger.error(`Unblock user error: ${error.message}`, error);
            throw error;
        }
    },

    // 시스템 통계
    getSystemStats: async () => {
        try {
            const totalUsersQuery = 'SELECT COUNT(*) as count FROM Users';
            const activeSubscriptionsQuery = "SELECT COUNT(*) as count FROM UserSubscriptions WHERE status = 'active'";
            const pendingSubscriptionsQuery = "SELECT COUNT(*) as count FROM UserSubscriptions WHERE status = 'pending'";
            const totalApiCallsQuery = 'SELECT COUNT(*) as count FROM ApiLogs';
            const blockedUsersQuery = 'SELECT COUNT(*) as count FROM Users WHERE is_blocked = 1';

            const [totalUsers, activeSubscriptions, pendingSubscriptions, totalApiCalls, blockedUsers] = await Promise.all([
                executeQuery(totalUsersQuery),
                executeQuery(activeSubscriptionsQuery),
                executeQuery(pendingSubscriptionsQuery),
                executeQuery(totalApiCallsQuery),
                executeQuery(blockedUsersQuery)
            ]);

            return {
                totalUsers: totalUsers[0].count,
                activeSubscriptions: activeSubscriptions[0].count,
                pendingSubscriptions: pendingSubscriptions[0].count,
                totalApiCalls: totalApiCalls[0].count,
                blockedUsers: blockedUsers[0].count
            };
        } catch (error) {
            logger.error(`Get system stats error: ${error.message}`, error);
            throw error;
        }
    }
};

module.exports = adminService;
