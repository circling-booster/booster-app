const ApiKey = require('../models/ApiKey');
const Subscription = require('../models/Subscription');
const { generateApiKey, generateApiSecret, hashApiSecret, generateUUID } = require('../utils/cryptoUtils');
const logger = require('../utils/logger');

const apiKeyService = {
    // API 키 생성
    createApiKey: async (userId, keyName) => {
        try {
            // 활성 구독 확인
            const subscription = await Subscription.findByUserId(userId);
            if (!subscription || subscription.status !== 'active') {
                throw {
                    statusCode: 403,
                    message: 'No active subscription found',
                    errorCode: 'FORBIDDEN'
                };
            }

            const apiKey = generateApiKey();
            const apiSecret = generateApiSecret();
            const apiSecretHash = hashApiSecret(apiSecret);

            const newKey = await ApiKey.create({
                id: generateUUID(),
                userId,
                keyName,
                apiKey,
                apiSecretHash
            });

            logger.info(`New API key created for user: ${userId}`);

            return {
                id: newKey.id,
                keyName: newKey.key_name,
                apiKey: newKey.api_key,
                apiSecret, // 한 번만 반환
                createdAt: newKey.created_at
            };
        } catch (error) {
            logger.error(`Create API key error: ${error.message}`, error);
            throw error;
        }
    },

    // 사용자의 API 키 조회
    getApiKeys: async (userId) => {
        try {
            const keys = await ApiKey.findByUserId(userId);
            return keys.map(key => ({
                id: key.id,
                keyName: key.key_name,
                apiKey: key.api_key,
                isActive: key.is_active === 1,
                lastUsed: key.last_used,
                createdAt: key.created_at,
                expiresAt: key.expires_at
            }));
        } catch (error) {
            logger.error(`Get API keys error: ${error.message}`, error);
            throw error;
        }
    },

    // API 키 비활성화
    revokeApiKey: async (keyId, userId) => {
        try {
            const key = await ApiKey.findById(keyId);
            if (!key || key.user_id !== userId) {
                throw {
                    statusCode: 404,
                    message: 'API key not found',
                    errorCode: 'NOT_FOUND'
                };
            }

            await ApiKey.revoke(keyId);
            logger.info(`API key revoked: ${keyId}`);
        } catch (error) {
            logger.error(`Revoke API key error: ${error.message}`, error);
            throw error;
        }
    }
};

module.exports = apiKeyService;