const adminService = require('../services/adminService');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');
const logger = require('../utils/logger');

const adminController = {
    // 모든 사용자 조회
    getAllUsers: async (req, res, next) => {
        try {
            const { page = 1, limit = 10 } = req.query;
            const result = await adminService.getAllUsers(parseInt(page), parseInt(limit));
            return successResponse(res, result, 'Users retrieved successfully');
        } catch (error) {
            logger.error(`Get all users error: ${error.message}`, error);
            next(error);
        }
    },

    // 대기 중인 구독 조회
    getPendingSubscriptions: async (req, res, next) => {
        try {
            const { page = 1, limit = 10 } = req.query;
            const subscriptions = await adminService.getPendingSubscriptions(parseInt(page), parseInt(limit));
            return successResponse(res, { subscriptions }, 'Pending subscriptions retrieved');
        } catch (error) {
            logger.error(`Get pending subscriptions error: ${error.message}`, error);
            next(error);
        }
    },

    // 구독 승인
    approveSubscription: async (req, res, next) => {
        try {
            const { id } = req.params;
            const approvedBy = req.user.userId;

            await adminService.approveSubscription(id, approvedBy);
            return successResponse(res, null, 'Subscription approved successfully');
        } catch (error) {
            logger.error(`Approve subscription error: ${error.message}`, error);
            next(error);
        }
    },

    // 구독 거절
    rejectSubscription: async (req, res, next) => {
        try {
            const { id } = req.params;
            const { reason } = req.body;

            if (!reason) {
                return errorResponse(res, 'Rejection reason is required', 'VALIDATION_ERROR', 400);
            }

            await adminService.rejectSubscription(id, reason);
            return successResponse(res, null, 'Subscription rejected successfully');
        } catch (error) {
            logger.error(`Reject subscription error: ${error.message}`, error);
            next(error);
        }
    },

    // 사용자 차단
    blockUser: async (req, res, next) => {
        try {
            const { userId } = req.params;
            const { reason } = req.body;

            if (!reason) {
                return errorResponse(res, 'Block reason is required', 'VALIDATION_ERROR', 400);
            }

            await adminService.blockUser(userId, reason);
            return successResponse(res, null, 'User blocked successfully');
        } catch (error) {
            logger.error(`Block user error: ${error.message}`, error);
            next(error);
        }
    },

    // 사용자 차단 해제
    unblockUser: async (req, res, next) => {
        try {
            const { userId } = req.params;

            await adminService.unblockUser(userId);
            return successResponse(res, null, 'User unblocked successfully');
        } catch (error) {
            logger.error(`Unblock user error: ${error.message}`, error);
            next(error);
        }
    },

    // 시스템 통계
    getSystemStats: async (req, res, next) => {
        try {
            const stats = await adminService.getSystemStats();
            return successResponse(res, stats, 'System statistics retrieved');
        } catch (error) {
            logger.error(`Get system stats error: ${error.message}`, error);
            next(error);
        }
    }
};

module.exports = adminController;