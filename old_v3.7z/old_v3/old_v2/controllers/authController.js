const authService = require('../services/authService');
const errorResponse = require('../utils/errorResponse');
const successResponse = require('../utils/successResponse');
const { validateSignupInput, validateEmail } = require('../utils/validationUtils');
const logger = require('../utils/logger');

const authController = {
    // 회원가입
    signup: async (req, res, next) => {
        try {
            const { firstName, lastName, email, phoneNumber, password, passwordConfirm } = req.body;

            // 입력값 검증
            const validation = validateSignupInput({
                firstName,
                lastName,
                email,
                phoneNumber,
                password,
                passwordConfirm
            });

            if (!validation.isValid) {
                return errorResponse(res, 'Validation failed', 'VALIDATION_ERROR', 400, validation.errors);
            }

            const result = await authService.registerUser({
                firstName,
                lastName,
                email,
                phoneNumber,
                password
            });

            return successResponse(res, result, 'User registered successfully', 201);
        } catch (error) {
            logger.error(`Signup error: ${error.message}`, error);
            next(error);
        }
    },

    // 로그인
    login: async (req, res, next) => {
        try {
            const { email, password } = req.body;

            if (!email || !password) {
                return errorResponse(res, 'Email and password are required', 'VALIDATION_ERROR', 400);
            }

            const result = await authService.loginUser(email, password);
            return successResponse(res, result, 'Login successful');
        } catch (error) {
            logger.error(`Login error: ${error.message}`, error);
            if (error.statusCode) {
                return errorResponse(res, error.message, error.errorCode, error.statusCode, error.details);
            }
            next(error);
        }
    },

    // 토큰 갱신
    refreshToken: async (req, res, next) => {
        try {
            const { refreshToken } = req.body;

            if (!refreshToken) {
                return errorResponse(res, 'Refresh token is required', 'VALIDATION_ERROR', 400);
            }

            const result = await authService.refreshAccessToken(refreshToken);
            return successResponse(res, result, 'Token refreshed successfully');
        } catch (error) {
            logger.error(`Refresh token error: ${error.message}`, error);
            if (error.statusCode) {
                return errorResponse(res, error.message, error.errorCode, error.statusCode);
            }
            next(error);
        }
    }
};

module.exports = authController;