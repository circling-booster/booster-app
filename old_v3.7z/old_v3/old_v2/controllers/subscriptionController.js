const Subscription = require('../models/Subscription');
const { generateUUID } = require('../utils/cryptoUtils');
const { executeQuery } = require('../config/database');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');
const logger = require('../utils/logger');

const subscriptionController = {
    // 구독 신청
    requestSubscription: async (req, res, next) => {
        try {
            const { tierId } = req.body;
            const userId = req.user.userId;

            if (!tierId) {
                return errorResponse(res, 'Tier ID is required', 'VALIDATION_ERROR', 400);
            }

            // 이미 구독 중인지 확인
            const existing = await Subscription.findByUserId(userId);
            if (existing && (existing.status === 'pending' || existing.status === 'active')) {
                return errorResponse(res, 'Already have an active or pending subscription', 'VALIDATION_ERROR', 400);
            }

            const subscription = await Subscription.create({
                id: generateUUID(),
                userId,
                tierId,
                status: 'pending'
            });

            logger.info(`Subscription requested: ${subscription.id}`);
            return successResponse(res, subscription, 'Subscription requested successfully', 201);
        } catch (error) {
            logger.error(`Request subscription error: ${error.message}`, error);
            next(error);
        }
    },

    // 사용자의 구독 조회
    getSubscription: async (req, res, next) => {
        try {
            const userId = req.user.userId;
            const subscription = await Subscription.findByUserId(userId);

            if (!subscription) {
                return successResponse(res, null, 'No subscription found');
            }

            return successResponse(res, subscription, 'Subscription retrieved successfully');
        } catch (error) {
            logger.error(`Get subscription error: ${error.message}`, error);
            next(error);
        }
    },

    // 구독 Tier 목록
    getTiers: async (req, res, next) => {
        try {
            const query = 'SELECT * FROM SubscriptionTiers WHERE is_active = 1 ORDER BY id';
            const tiers = await executeQuery(query);

            const formatted = tiers.map(t => ({
                id: t.id,
                name: t.tier_name,
                limit: t.api_call_limit,
                price: t.price_monthly,
                description: t.description
            }));

            return successResponse(res, { tiers: formatted }, 'Subscription tiers retrieved');
        } catch (error) {
            logger.error(`Get tiers error: ${error.message}`, error);
            next(error);
        }
    }
};

module.exports = subscriptionController;
