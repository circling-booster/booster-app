const apiKeyService = require('../services/apiKeyService');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');
const logger = require('../utils/logger');

const apiKeyController = {
    // API 키 생성
    createApiKey: async (req, res, next) => {
        try {
            const { keyName } = req.body;
            const userId = req.user.userId;

            if (!keyName) {
                return errorResponse(res, 'Key name is required', 'VALIDATION_ERROR', 400);
            }

            const result = await apiKeyService.createApiKey(userId, keyName);
            return successResponse(res, result, 'API key created successfully', 201);
        } catch (error) {
            logger.error(`Create API key error: ${error.message}`, error);
            if (error.statusCode) {
                return errorResponse(res, error.message, error.errorCode, error.statusCode);
            }
            next(error);
        }
    },

    // API 키 조회
    getApiKeys: async (req, res, next) => {
        try {
            const userId = req.user.userId;
            const keys = await apiKeyService.getApiKeys(userId);
            return successResponse(res, { keys }, 'API keys retrieved successfully');
        } catch (error) {
            logger.error(`Get API keys error: ${error.message}`, error);
            next(error);
        }
    },

    // API 키 비활성화
    revokeApiKey: async (req, res, next) => {
        try {
            const { id } = req.params;
            const userId = req.user.userId;

            await apiKeyService.revokeApiKey(id, userId);
            return successResponse(res, null, 'API key revoked successfully');
        } catch (error) {
            logger.error(`Revoke API key error: ${error.message}`, error);
            if (error.statusCode) {
                return errorResponse(res, error.message, error.errorCode, error.statusCode);
            }
            next(error);
        }
    }
};

module.exports = apiKeyController;