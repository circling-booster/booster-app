/**
 * Booster API Server - Main Entry Point
 * Azure App Service (Linux, Node.js 24 LTS)
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const { initializeDatabase } = require('./config/database');
const errorHandler = require('./middleware/errorHandler');
const { ipLimiter } = require('./middleware/rateLimitMiddleware');
const logger = require('./utils/logger');

// Routes
const authRoutes = require('./routes/authRoutes');
const apiKeyRoutes = require('./routes/apiKeyRoutes');
const subscriptionRoutes = require('./routes/subscriptionRoutes');
const userRoutes = require('./routes/userRoutes');
const adminRoutes = require('./routes/adminRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// ==================== Middleware Setup ====================

// Security Headers
app.use(helmet());

// CORS Configuration
app.use(cors({
    origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',').map(o => o.trim()) : '*',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key', 'X-API-Secret']
}));

// Body Parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Logging Middleware
const morganFormat = process.env.NODE_ENV === 'production' ? 'combined' : 'dev';
app.use(morgan(morganFormat, {
    stream: { write: (message) => logger.info(message.trim()) }
}));

// Request Logging
app.use((req, res, next) => {
    const startTime = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - startTime;
        logger.debug(`${req.method} ${req.path} - ${res.statusCode} - ${duration}ms`);
    });
    next();
});

// Rate Limiting (IP-based)
app.use(ipLimiter);

// ==================== API Endpoints ====================

// Health Check Endpoint (No Auth Required)
app.get('/health', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Server is running',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// API Routes with /api prefix
app.use('/api/auth', authRoutes);
app.use('/api/api-keys', apiKeyRoutes);
app.use('/api/subscriptions', subscriptionRoutes);
app.use('/api/users', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/dashboard', dashboardRoutes);

// ==================== Static Files ====================

// Serve Frontend Static Files
app.use(express.static('frontend', {
    maxAge: '1h',
    etag: false
}));

// Serve index.html for SPA routing
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/frontend/index.html');
});

// ==================== Error Handling ====================

// 404 Handler (Not Found)
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Resource not found',
        errorCode: 'NOT_FOUND',
        path: req.path,
        timestamp: new Date().toISOString()
    });
});

// Global Error Handler (Must be last)
app.use(errorHandler);

// ==================== Server Startup ====================

const startServer = async () => {
    try {
        // Initialize Database Connection
        logger.info('Initializing database connection pool...');
        await initializeDatabase();
        logger.info('✓ Database connection pool established successfully');

        // Start HTTP Server
        app.listen(PORT, () => {
            logger.info(`
╔════════════════════════════════════════════════╗
║  🚀 Booster API Server Started Successfully    ║
╠════════════════════════════════════════════════╣
║  Port: ${PORT}
║  Environment: ${process.env.NODE_ENV || 'development'}
║  Timestamp: ${new Date().toISOString()}
╚════════════════════════════════════════════════╝
            `);
        });
    } catch (error) {
        logger.error(`❌ Failed to start server: ${error.message}`, error);
        process.exit(1);
    }
};

// ==================== Graceful Shutdown ====================

process.on('SIGTERM', () => {
    logger.warn('⚠️  SIGTERM signal received: closing HTTP server gracefully');
    process.exit(0);
});

process.on('SIGINT', () => {
    logger.warn('⚠️  SIGINT signal received: closing HTTP server gracefully');
    process.exit(0);
});

// Unhandled Rejection Handler
process.on('unhandledRejection', (reason, promise) => {
    logger.error(`Unhandled Rejection at: ${promise}, reason: ${reason}`);
});

// Uncaught Exception Handler
process.on('uncaughtException', (error) => {
    logger.error('Uncaught Exception:', error);
    process.exit(1);
});

// ==================== Start Application ====================

startServer();

module.exports = app;