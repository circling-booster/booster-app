const logger = require('../utils/logger');
const errorResponse = require('../utils/errorResponse');

const errorHandler = (err, req, res, next) => {
    logger.error(`Error: ${err.message || JSON.stringify(err)}`, err);

    // 데이터베이스 연결 오류
    if (err.code === 'ECONNREFUSED' || err.code === 'ETIMEOUT') {
        return errorResponse(
            res,
            'Database connection error',
            'DATABASE_ERROR',
            503,
            { details: err.message }
        );
    }

    // 검증 오류
    if (err.statusCode === 400 && err.errorCode === 'VALIDATION_ERROR') {
        return errorResponse(res, err.message, err.errorCode, 400, err.details);
    }

    // 커스텀 에러
    if (err.statusCode) {
        return errorResponse(
            res,
            err.message,
            err.errorCode || 'ERROR',
            err.statusCode,
            err.details
        );
    }

    // 일반 에러
    return errorResponse(
        res,
        err.message || 'Internal server error',
        'INTERNAL_ERROR',
        500
    );
};

module.exports = errorHandler;