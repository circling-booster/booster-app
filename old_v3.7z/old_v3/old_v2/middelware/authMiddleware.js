const { extractBearerToken, verifyAccessToken } = require('../utils/tokenUtils');
const errorResponse = require('../utils/errorResponse');
const logger = require('../utils/logger');

const authMiddleware = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        const token = extractBearerToken(authHeader);

        if (!token) {
            return errorResponse(res, 'Missing authorization token', 'UNAUTHORIZED', 401);
        }

        const decoded = verifyAccessToken(token);
        req.user = {
            userId: decoded.userId,
            isAdmin: decoded.isAdmin
        };

        next();
    } catch (error) {
        logger.error(`Auth middleware error: ${error.message}`, error);
        
        if (error.statusCode) {
            return errorResponse(res, error.message, error.errorCode, error.statusCode);
        }

        return errorResponse(res, 'Authentication failed', 'UNAUTHORIZED', 401);
    }
};

const adminAuthMiddleware = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        const token = extractBearerToken(authHeader);

        if (!token) {
            return errorResponse(res, 'Missing authorization token', 'UNAUTHORIZED', 401);
        }

        const decoded = verifyAccessToken(token);
        
        if (!decoded.isAdmin) {
            return errorResponse(res, 'Admin access required', 'FORBIDDEN', 403);
        }

        req.user = {
            userId: decoded.userId,
            isAdmin: decoded.isAdmin
        };

        next();
    } catch (error) {
        logger.error(`Admin auth middleware error: ${error.message}`, error);
        
        if (error.statusCode) {
            return errorResponse(res, error.message, error.errorCode, error.statusCode);
        }

        return errorResponse(res, 'Authentication failed', 'UNAUTHORIZED', 401);
    }
};

module.exports = {
    authMiddleware,
    adminAuthMiddleware
};