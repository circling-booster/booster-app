const rateLimit = require('express-rate-limit');
const { executeQuery } = require('../config/database');
const logger = require('../utils/logger');

const WINDOW_MS = parseInt(process.env.RATE_LIMIT_WINDOW_MS || '3600000');
const MAX_REQUESTS = parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100');
const WHITELIST_IPS = process.env.RATE_LIMIT_WHITELIST_IPS 
    ? process.env.RATE_LIMIT_WHITELIST_IPS.split(',').map(ip => ip.trim())
    : [];

const ipLimiter = rateLimit({
    windowMs: WINDOW_MS,
    max: MAX_REQUESTS,
    message: 'Too many requests from this IP, please try again later.',
    skip: (req) => {
        const clientIp = req.ip || req.connection.remoteAddress;
        return WHITELIST_IPS.includes(clientIp);
    },
    handler: (req, res) => {
        res.status(429).json({
            success: false,
            message: 'Rate limit exceeded',
            errorCode: 'RATE_LIMIT_EXCEEDED',
            timestamp: new Date().toISOString()
        });
    }
});

const apiKeyRateLimiter = async (req, res, next) => {
    try {
        const apiKey = req.headers['x-api-key'];
        
        if (!apiKey) {
            return next();
        }

        // API 키의 시간당 제한 조회
        const query = `
            SELECT 
                ak.id,
                st.api_call_limit,
                COUNT(al.id) as current_hour_requests
            FROM ApiKeys ak
            LEFT JOIN ApiLogs al ON ak.id = al.api_key_id 
                AND al.created_at > DATEADD(HOUR, -1, GETUTCDATE())
            LEFT JOIN Users u ON ak.user_id = u.id
            LEFT JOIN UserSubscriptions us ON u.id = us.user_id AND us.status = 'active'
            LEFT JOIN SubscriptionTiers st ON us.tier_id = st.id
            WHERE ak.api_key = @apiKey
            GROUP BY ak.id, st.api_call_limit
        `;

        const result = await executeQuery(query, { apiKey });

        if (result.length === 0 || !result[0].api_call_limit) {
            return res.status(429).json({
                success: false,
                message: 'Rate limit exceeded',
                errorCode: 'RATE_LIMIT_EXCEEDED',
                timestamp: new Date().toISOString()
            });
        }

        const { api_call_limit, current_hour_requests } = result[0];
        const hourlyLimit = Math.ceil(api_call_limit / 730); // 월한을 시간으로 변환

        if (current_hour_requests >= hourlyLimit) {
            return res.status(429).json({
                success: false,
                message: 'Rate limit exceeded',
                errorCode: 'RATE_LIMIT_EXCEEDED',
                timestamp: new Date().toISOString()
            });
        }

        next();
    } catch (error) {
        logger.error(`Rate limit middleware error: ${error.message}`, error);
        next();
    }
};

module.exports = {
    ipLimiter,
    apiKeyRateLimiter
};