const express = require('express');
const router = express.Router();
const subscriptionController = require('../controllers/subscriptionController');
const { authMiddleware } = require('../middleware/authMiddleware');

router.post('/request', authMiddleware, subscriptionController.requestSubscription);
router.get('/', authMiddleware, subscriptionController.getSubscription);
router.get('/tiers', subscriptionController.getTiers);

module.exports = router;