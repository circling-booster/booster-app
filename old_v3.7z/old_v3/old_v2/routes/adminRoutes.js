const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { adminAuthMiddleware } = require('../middleware/authMiddleware');

router.get('/users', adminAuthMiddleware, adminController.getAllUsers);
router.get('/subscriptions/pending', adminAuthMiddleware, adminController.getPendingSubscriptions);
router.post('/subscriptions/:id/approve', adminAuthMiddleware, adminController.approveSubscription);
router.post('/subscriptions/:id/reject', adminAuthMiddleware, adminController.rejectSubscription);
router.post('/users/:userId/block', adminAuthMiddleware, adminController.blockUser);
router.post('/users/:userId/unblock', adminAuthMiddleware, adminController.unblockUser);
router.get('/stats', adminAuthMiddleware, adminController.getSystemStats);

module.exports = router;