const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { authMiddleware } = require('../middleware/authMiddleware');
const successResponse = require('../utils/successResponse');
const errorResponse = require('../utils/errorResponse');
const logger = require('../utils/logger');

// 프로필 조회
router.get('/profile', authMiddleware, async (req, res, next) => {
    try {
        const user = await User.findById(req.user.userId);
        if (!user) {
            return errorResponse(res, 'User not found', 'NOT_FOUND', 404);
        }

        return successResponse(res, {
            id: user.id,
            email: user.email,
            firstName: user.first_name,
            lastName: user.last_name,
            phoneNumber: user.phone_number,
            createdAt: user.created_at
        });
    } catch (error) {
        logger.error(`Get profile error: ${error.message}`, error);
        next(error);
    }
});

module.exports = router;