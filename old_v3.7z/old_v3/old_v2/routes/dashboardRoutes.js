const express = require('express');
const router = express.Router();
const ApiLog = require('../models/ApiLog');
const { authMiddleware } = require('../middleware/authMiddleware');
const { executeQuery } = require('../config/database');
const successResponse = require('../utils/successResponse');
const logger = require('../utils/logger');

// 대시보드 통계
router.get('/stats', authMiddleware, async (req, res, next) => {
    try {
        const userId = req.user.userId;

        // 총 API 호출 수
        const totalCallsQuery = 'SELECT COUNT(*) as count FROM ApiLogs WHERE user_id = @userId';
        const totalCalls = await executeQuery(totalCallsQuery, { userId });

        // 엔드포인트별 통계
        const endpointStats = await ApiLog.getEndpointStats(userId);

        // 상태 코드별 통계
        const statusCodeStats = await ApiLog.getStatusCodeStats(userId);

        return successResponse(res, {
            totalCalls: totalCalls[0].count,
            endpointStats,
            statusCodeStats
        }, 'Dashboard statistics retrieved');
    } catch (error) {
        logger.error(`Dashboard stats error: ${error.message}`, error);
        next(error);
    }
});

// API 로그 조회
router.get('/logs', authMiddleware, async (req, res, next) => {
    try {
        const userId = req.user.userId;
        const { page = 1, limit = 20 } = req.query;

        const logs = await ApiLog.findByUserId(userId, parseInt(page), parseInt(limit));

        return successResponse(res, {
            logs,
            page: parseInt(page),
            limit: parseInt(limit)
        }, 'API logs retrieved');
    } catch (error) {
        logger.error(`Get logs error: ${error.message}`, error);
        next(error);
    }
});

module.exports = router;