const express = require('express');
const router = express.Router();
const apiKeyController = require('../controllers/apiKeyController');
const { authMiddleware } = require('../middleware/authMiddleware');
const { apiKeyRateLimiter } = require('../middleware/rateLimitMiddleware');

router.post('/', authMiddleware, apiKeyRateLimiter, apiKeyController.createApiKey);
router.get('/', authMiddleware, apiKeyController.getApiKeys);
router.delete('/:id', authMiddleware, apiKeyController.revokeApiKey);

module.exports = router;