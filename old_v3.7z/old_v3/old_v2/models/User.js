const { executeQuery, executeNonQuery } = require('../config/database');

const User = {
    // 이메일로 사용자 조회
    findByEmail: async (email) => {
        const query = `
            SELECT * FROM Users WHERE email = @email
        `;
        const result = await executeQuery(query, { email });
        return result.length > 0 ? result[0] : null;
    },

    // ID로 사용자 조회
    findById: async (id) => {
        const query = `
            SELECT * FROM Users WHERE id = @id
        `;
        const result = await executeQuery(query, { id });
        return result.length > 0 ? result[0] : null;
    },

    // 새 사용자 생성
    create: async (userData) => {
        const query = `
            INSERT INTO Users (id, first_name, last_name, email, phone_number, password_hash, is_active, is_admin)
            VALUES (@id, @firstName, @lastName, @email, @phoneNumber, @passwordHash, @isActive, @isAdmin)
        `;
        
        await executeNonQuery(query, {
            id: userData.id,
            firstName: userData.firstName,
            lastName: userData.lastName,
            email: userData.email,
            phoneNumber: userData.phoneNumber,
            passwordHash: userData.passwordHash,
            isActive: userData.isActive !== false ? 1 : 0,
            isAdmin: userData.isAdmin === true ? 1 : 0
        });

        return User.findById(userData.id);
    },

    // 마지막 로그인 시간 업데이트
    updateLastLogin: async (userId) => {
        const query = `
            UPDATE Users SET last_login = GETUTCDATE() WHERE id = @userId
        `;
        
        await executeNonQuery(query, { userId });
    },

    // 사용자 차단
    blockUser: async (userId, reason) => {
        const query = `
            UPDATE Users SET is_blocked = 1, blocked_reason = @reason WHERE id = @userId
        `;
        
        await executeNonQuery(query, { userId, reason });
    },

    // 사용자 차단 해제
    unblockUser: async (userId) => {
        const query = `
            UPDATE Users SET is_blocked = 0, blocked_reason = NULL WHERE id = @userId
        `;
        
        await executeNonQuery(query, { userId });
    },

    // 모든 사용자 조회 (페이지네이션)
    findAll: async (page = 1, limit = 10) => {
        const offset = (page - 1) * limit;
        const query = `
            SELECT * FROM Users ORDER BY created_at DESC OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY
        `;
        
        return await executeQuery(query, { offset, limit });
    },

    // 총 사용자 수
    count: async () => {
        const query = `SELECT COUNT(*) as total FROM Users`;
        const result = await executeQuery(query);
        return result[0].total;
    }
};

module.exports = User;