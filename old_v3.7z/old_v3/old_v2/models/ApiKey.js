const { executeQuery, executeNonQuery } = require('../config/database');

const ApiKey = {
    // API 키로 조회
    findByKey: async (apiKey) => {
        const query = `
            SELECT ak.*, u.is_active as user_is_active, us.status as subscription_status
            FROM ApiKeys ak
            LEFT JOIN Users u ON ak.user_id = u.id
            LEFT JOIN UserSubscriptions us ON u.id = us.user_id AND us.status = 'active'
            WHERE ak.api_key = @apiKey AND ak.is_active = 1
        `;
        
        const result = await executeQuery(query, { apiKey });
        return result.length > 0 ? result[0] : null;
    },

    // ID로 API 키 조회
    findById: async (id) => {
        const query = `
            SELECT * FROM ApiKeys WHERE id = @id
        `;
        
        const result = await executeQuery(query, { id });
        return result.length > 0 ? result[0] : null;
    },

    // 사용자의 모든 API 키 조회
    findByUserId: async (userId) => {
        const query = `
            SELECT * FROM ApiKeys WHERE user_id = @userId ORDER BY created_at DESC
        `;
        
        return await executeQuery(query, { userId });
    },

    // 새 API 키 생성
    create: async (keyData) => {
        const query = `
            INSERT INTO ApiKeys (id, user_id, key_name, api_key, api_secret_hash, is_active)
            VALUES (@id, @userId, @keyName, @apiKey, @apiSecretHash, @isActive)
        `;
        
        await executeNonQuery(query, {
            id: keyData.id,
            userId: keyData.userId,
            keyName: keyData.keyName,
            apiKey: keyData.apiKey,
            apiSecretHash: keyData.apiSecretHash,
            isActive: 1
        });

        return ApiKey.findById(keyData.id);
    },

    // API 키 비활성화
    revoke: async (id) => {
        const query = `
            UPDATE ApiKeys SET is_active = 0 WHERE id = @id
        `;
        
        await executeNonQuery(query, { id });
    },

    // 마지막 사용 시간 업데이트
    updateLastUsed: async (id) => {
        const query = `
            UPDATE ApiKeys SET last_used = GETUTCDATE() WHERE id = @id
        `;
        
        await executeNonQuery(query, { id });
    }
};

module.exports = ApiKey;