const { executeQuery, executeNonQuery } = require('../config/database');

const Subscription = {
    // 사용자의 구독 조회
    findByUserId: async (userId) => {
        const query = `
            SELECT us.*, st.tier_name, st.api_call_limit
            FROM UserSubscriptions us
            LEFT JOIN SubscriptionTiers st ON us.tier_id = st.id
            WHERE us.user_id = @userId
            ORDER BY us.created_at DESC
        `;
        
        const result = await executeQuery(query, { userId });
        return result.length > 0 ? result[0] : null;
    },

    // 구독 생성
    create: async (subscriptionData) => {
        const query = `
            INSERT INTO UserSubscriptions (id, user_id, tier_id, status)
            VALUES (@id, @userId, @tierId, @status)
        `;
        
        await executeNonQuery(query, {
            id: subscriptionData.id,
            userId: subscriptionData.userId,
            tierId: subscriptionData.tierId,
            status: subscriptionData.status || 'pending'
        });

        return Subscription.findByUserId(subscriptionData.userId);
    },

    // 대기 중인 구독 조회
    findPending: async (page = 1, limit = 10) => {
        const offset = (page - 1) * limit;
        const query = `
            SELECT us.*, st.tier_name, st.api_call_limit, u.email, u.first_name, u.last_name
            FROM UserSubscriptions us
            LEFT JOIN SubscriptionTiers st ON us.tier_id = st.id
            LEFT JOIN Users u ON us.user_id = u.id
            WHERE us.status = 'pending'
            ORDER BY us.created_at DESC
            OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY
        `;
        
        return await executeQuery(query, { offset, limit });
    },

    // 구독 승인
    approve: async (subscriptionId, approvedBy) => {
        const query = `
            UPDATE UserSubscriptions 
            SET status = 'active', approval_date = GETUTCDATE(), approved_by = @approvedBy
            WHERE id = @subscriptionId
        `;
        
        await executeNonQuery(query, { subscriptionId, approvedBy });
    },

    // 구독 거절
    reject: async (subscriptionId, reason) => {
        const query = `
            UPDATE UserSubscriptions 
            SET status = 'cancelled', rejection_reason = @reason
            WHERE id = @subscriptionId
        `;
        
        await executeNonQuery(query, { subscriptionId, reason });
    }
};

module.exports = Subscription;