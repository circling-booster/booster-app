const { executeQuery, executeNonQuery } = require('../config/database');

const ApiLog = {
    // 로그 기록 생성
    create: async (logData) => {
        const query = `
            INSERT INTO ApiLogs (id, api_key_id, user_id, endpoint, method, status_code, response_time_ms, ip_address, request_body, error_message)
            VALUES (@id, @apiKeyId, @userId, @endpoint, @method, @statusCode, @responseTimeMs, @ipAddress, @requestBody, @errorMessage)
        `;
        
        await executeNonQuery(query, {
            id: logData.id,
            apiKeyId: logData.apiKeyId || null,
            userId: logData.userId || null,
            endpoint: logData.endpoint,
            method: logData.method,
            statusCode: logData.statusCode,
            responseTimeMs: logData.responseTimeMs || null,
            ipAddress: logData.ipAddress,
            requestBody: logData.requestBody ? JSON.stringify(logData.requestBody) : null,
            errorMessage: logData.errorMessage || null
        });
    },

    // 사용자별 로그 조회
    findByUserId: async (userId, page = 1, limit = 20) => {
        const offset = (page - 1) * limit;
        const query = `
            SELECT TOP (@limit) * FROM ApiLogs 
            WHERE user_id = @userId 
            ORDER BY created_at DESC
            OFFSET @offset ROWS
        `;
        
        return await executeQuery(query, { userId, offset, limit });
    },

    // 엔드포인트별 통계
    getEndpointStats: async (userId) => {
        const query = `
            SELECT 
                endpoint,
                COUNT(*) as total_calls,
                AVG(response_time_ms) as avg_response_time,
                SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as error_count
            FROM ApiLogs
            WHERE user_id = @userId AND created_at > DATEADD(DAY, -30, GETUTCDATE())
            GROUP BY endpoint
            ORDER BY total_calls DESC
        `;
        
        return await executeQuery(query, { userId });
    },

    // 상태 코드별 통계
    getStatusCodeStats: async (userId) => {
        const query = `
            SELECT 
                status_code,
                COUNT(*) as count
            FROM ApiLogs
            WHERE user_id = @userId AND created_at > DATEADD(DAY, -30, GETUTCDATE())
            GROUP BY status_code
        `;
        
        return await executeQuery(query, { userId });
    },

    // 응답 시간 분포
    getResponseTimeDistribution: async (userId) => {
        const query = `
            SELECT 
                CASE 
                    WHEN response_time_ms < 100 THEN '0-100ms'
                    WHEN response_time_ms < 500 THEN '100-500ms'
                    WHEN response_time_ms < 1000 THEN '500-1000ms'
                    ELSE '>1000ms'
                END as range,
                COUNT(*) as count
            FROM ApiLogs
            WHERE user_id = @userId AND created_at > DATEADD(DAY, -30, GETUTCDATE()) AND response_time_ms IS NOT NULL
            GROUP BY 
                CASE 
                    WHEN response_time_ms < 100 THEN '0-100ms'
                    WHEN response_time_ms < 500 THEN '100-500ms'
                    WHEN response_time_ms < 1000 THEN '500-1000ms'
                    ELSE '>1000ms'
                END
        `;
        
        return await executeQuery(query, { userId });
    },

    // 오래된 로그 삭제 (기본 90일)
    deleteOldLogs: async (daysOld = 90) => {
        const query = `
            DELETE FROM ApiLogs WHERE created_at < DATEADD(DAY, -@daysOld, GETUTCDATE())
        `;
        
        const result = await executeNonQuery(query, { daysOld });
        return result.rowsAffected;
    }
};

module.exports = ApiLog;